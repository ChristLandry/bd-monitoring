import { Injectable, Logger } from '@nestjs/common';
import { Client as PgClient } from 'pg';
import * as mysql from 'mysql2/promise';
import * as mssql from 'mssql';
import { MongoClient } from 'mongodb';
import { ConnectionEntity } from '../definitions/model/connection.entity';
import { DbType } from '../definitions/model/db-type.enum';
import { EncryptionService } from '../../common/services/encryption.service';
import {
  QueryExecutionOutcome,
  QueryExecutionResult,
} from '../definitions/class/query-execution-result.class';

export interface ExecuteQueryParams {
  connection: ConnectionEntity;
  sql: string;
  parameters?: Record<string, unknown>;
  timeoutSeconds: number;
  queryType?: 'SQL' | 'FUNCTION' | 'PROCEDURE';
}

@Injectable()
export class QueryExecutionService {
  /**
   * Service central d'exécution de requêtes vers différents SGBD.
   * - Gère le binding de paramètres nommés
   * - Sélectionne le driver (Postgres, MySQL, MSSQL, MongoDB, Oracle)
   * - Applique un timeout global par requête
   * - Normalise les appels de type FUNCTION/PROCEDURE selon le SGBD
   * - Extrait et renvoie le résultat brut et une valeur "value" générique
   */
  private readonly logger = new Logger(QueryExecutionService.name);
  private readonly runningJobs = new Set<string>();

  constructor(private readonly encryption: EncryptionService) {}

  async execute(params: ExecuteQueryParams): Promise<QueryExecutionOutcome> {
    // Création d'une clé de verrou pour empêcher l'exécution concurrente
    // de la même requête (même connection + même texte SQL)
    const lockKey = `${params.connection.id}:${this.hashSql(params.sql)}`;
    if (this.runningJobs.has(lockKey)) {
      return {
        success: false,
        error: {
          code: 'ERREUR_CONNEXION',
          message: 'Exécution concurrente refusée pour cette requête',
          durationMs: 0,
        },
      };
    }
    this.runningJobs.add(lockKey);
    const started = Date.now();
    try {
      // Début du chronométrage
      const password = this.encryption.decrypt(
        params.connection.passwordEncrypted,
      );
      // Normaliser la requête si elle est marquée comme FUNCTION/PROCEDURE
      const resolvedSql = this.normalizeSqlForType(
        params.sql,
        params.queryType,
        params.connection.type,
      );

      // Remplacer les paramètres nommés par des placeholders adaptés au driver
      const { sql, values } = this.bindParameters(
        resolvedSql,
        params.parameters ?? {},
      );
      const result = await this.runWithTimeout(
        () =>
          this.dispatchDriver(params.connection, sql, values, password),
        params.timeoutSeconds * 1000,
      );
      // Calculer la durée et extraire la valeur renvoyée par la requête
      const durationMs = Date.now() - started;
      const value = this.extractResultValue(result);
      return {
        success: true,
        result: {
          value,
          durationMs,
          rawRows: result.rows,
          rowCount: result.rowCount,
        },
      };
    } catch (err) {
      const durationMs = Date.now() - started;
      return { success: false, error: this.mapError(err, durationMs) };
    } finally {
      this.runningJobs.delete(lockKey);
    }
  }

  async testConnection(
    connection: ConnectionEntity,
  ): Promise<{ success: boolean; responseTimeMs: number; serverVersion?: string; message?: string }> {
    const started = Date.now();
    try {
      const password = this.encryption.decrypt(connection.passwordEncrypted);
      const probeSql = this.getProbeSql(connection.type);
      await this.runWithTimeout(
        () => this.dispatchDriver(connection, probeSql, [], password),
        10000,
      );
      return {
        success: true,
        responseTimeMs: Date.now() - started,
        serverVersion: connection.type,
      };
    } catch (err) {
      return {
        success: false,
        responseTimeMs: Date.now() - started,
        message: err instanceof Error ? err.message : String(err),
      };
    }
  }

  private getProbeSql(type: DbType): string {
    switch (type) {
      case DbType.ORACLE:
        return 'SELECT 1 FROM DUAL';
      case DbType.MSSQL:
        return 'SELECT 1 AS val';
      case DbType.MONGODB:
        return '{"ping":1}';
      case DbType.POSTGRESQL:
        return 'SELECT 1 AS val';
      case DbType.MYSQL:
        return 'SELECT 1 AS val';
      case DbType.MARIADB:
        return 'SELECT 1 AS val';
      default:
        return 'SELECT 1 AS val';
    }
  }

  private bindParameters(
    sql: string,
    params: Record<string, unknown>,
  ): { sql: string; values: unknown[] } {
    const values: unknown[] = [];
    let index = 0;

    // Support de deux syntaxes de paramètres dans les requêtes :
    // - {{name}}  (utilisé parfois dans les templates)
    // - :name     (paramètres nommés de style SQL)
    // Les deux sont convertis en placeholders positionnels ($1, $2, ...)
    let bound = sql.replace(/\{\{(\w+)\}\}/g, (_, key: string) => {
      values.push(params[key] ?? null);
      index++;
      return this.placeholder(index);
    });

    bound = bound.replace(/:(\w+)/g, (_, key: string) => {
      if (!(key in params)) {
        return `:${key}`;
      }
      values.push(params[key]);
      index++;
      return this.placeholder(index);
    });

    return { sql: bound, values };
  }

  private placeholder(index: number): string {
    // Placeholders positionnels attendus par la plupart des drivers PostgreSQL
    // (ou utilisés comme intermédiaire pour être transformés pour MySQL/MSSQL)
    return `$${index}`;
  }

  private async dispatchDriver(
    connection: ConnectionEntity,
    sql: string,
    values: unknown[],
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    // Délègue l'exécution au driver adapté selon le type de base
    switch (connection.type) {
      case DbType.POSTGRESQL:
        return this.executePostgres(connection, sql, values, password);
      case DbType.MYSQL:
      case DbType.MARIADB:
        return this.executeMysql(connection, sql, values, password);
      case DbType.MSSQL:
        return this.executeMssql(connection, sql, values, password);
      case DbType.MONGODB:
        return this.executeMongo(connection, sql, password);
      case DbType.ORACLE:
        return this.executeOracle(connection, sql, values, password);
      default:
        throw new Error(`Type de base non supporté: ${connection.type}`);
    }
  }

  private async executePostgres(
    conn: ConnectionEntity,
    sql: string,
    values: unknown[],
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    // Postgres : utilise le client `pg`. Les placeholders $n sont natifs.
    const client = new PgClient({
      host: conn.host,
      port: conn.port,
      database: conn.database,
      user: conn.username,
      password,
      ssl: conn.sslEnabled ? { rejectUnauthorized: false } : undefined,
      ...(conn.options as object),
    });
    await client.connect();
    try {
      const res = await client.query(sql, values);
      return { rows: res.rows, rowCount: res.rowCount ?? res.rows.length };
    } finally {
      await client.end();
    }
  }

  private async executeMysql(
    conn: ConnectionEntity,
    sql: string,
    values: unknown[],
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    // MySQL/MariaDB : le driver attend `?` comme placeholder.
    // On convertit donc `$1` `$2` -> `?` et passe un tableau `values`.
    const mysqlSql = sql.replace(/\$(\d+)/g, '?');
    const pool = await mysql.createConnection({
      host: conn.host,
      port: conn.port,
      database: conn.database,
      user: conn.username,
      password,
      ssl: conn.sslEnabled ? {} : undefined,
      ...(conn.options as mysql.ConnectionOptions),
    });
    try {
      const [rows] = await pool.execute(
        mysqlSql,
        values as (string | number | null)[],
      );
      const arr = Array.isArray(rows) ? rows : [rows];
      return { rows: arr as unknown[], rowCount: arr.length };
    } finally {
      await pool.end();
    }
  }

  private async executeMssql(
    conn: ConnectionEntity,
    sql: string,
    values: unknown[],
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    // MSSQL : on utilise des paramètres nommés @p1, @p2 etc.
    const pool = await mssql.connect({
      server: conn.host,
      port: conn.port,
      database: conn.database,
      user: conn.username,
      password,
      options: {
        encrypt: conn.sslEnabled,
        trustServerCertificate: true,
        ...(conn.options as mssql.IOptions),
      },
    });
    try {
      const request = pool.request();
      // Attacher les valeurs au Request MSSQL
      values.forEach((v, i) => request.input(`p${i + 1}`, v));
      const mssqlSql = sql.replace(/\$(\d+)/g, (_, n) => `@p${n}`);
      const result = await request.query(mssqlSql);
      const rows = result.recordset ?? [];
      return { rows, rowCount: rows.length };
    } finally {
      await pool.close();
    }
  }

  private async executeMongo(
    conn: ConnectionEntity,
    sql: string,
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    const uri =
      (conn.options?.uri as string) ??
      `mongodb://${encodeURIComponent(conn.username)}:${encodeURIComponent(password)}@${conn.host}:${conn.port}/${conn.database}`;
    const client = new MongoClient(uri, {
      tls: conn.sslEnabled,
    });
    await client.connect();
    try {
      // Pour MongoDB, `sql` contient un JSON décrivant l'opération.
      // Exemple: { "collection": "coll", "pipeline": [ ... ] }
      const parsed = JSON.parse(sql) as {
        collection: string;
        pipeline?: object[];
        aggregate?: string;
      };
      const db = client.db(conn.database);
      if (parsed.collection && parsed.pipeline) {
        const cursor = db
          .collection(parsed.collection)
          .aggregate(parsed.pipeline);
        const rows = await cursor.toArray();
        return { rows, rowCount: rows.length };
      }
      // Si on ne fournit pas d'opération, on fait un ping minimal
      await db.command({ ping: 1 });
      return { rows: [{ val: 1 }], rowCount: 1 };
    } finally {
      await client.close();
    }
  }

  private async executeOracle(
    conn: ConnectionEntity,
    sql: string,
    values: unknown[],
    password: string,
  ): Promise<{ rows: unknown[]; rowCount: number }> {
    let oracledb: typeof import('oracledb');
    try {
      oracledb = await import('oracledb');
    } catch {
      throw new Error(
        'Driver oracledb non installé. Exécutez: npm install oracledb',
      );
    }
    const connection = await oracledb.getConnection({
      user: conn.username,
      password,
      connectString: `${conn.host}:${conn.port}/${conn.database}`,
      ...(conn.options as object),
    });
    try {
      // Oracle utilise des bind variables : :1, :2, ...
      const oracleSql = sql.replace(/\$(\d+)/g, (_, n) => `:${n}`);
      const result = await connection.execute(oracleSql, values, {
        outFormat: oracledb.OUT_FORMAT_OBJECT,
      });
      const rows = (result.rows ?? []) as unknown[];
      return { rows, rowCount: rows.length };
    } finally {
      await connection.close();
    }
  }

  private normalizeSqlForType(
    sql: string,
    queryType: ExecuteQueryParams['queryType'],
    dbType: DbType,
  ): string {
    // Si pas de type fourni, on considère que c'est une requête SQL classique
    if (!queryType || queryType === 'SQL') {
      return sql;
    }
    const trimmed = sql.trim();
    const alreadyWrapped = /^(SELECT|CALL|EXEC|BEGIN|WITH)\b/i.test(trimmed);
    if (alreadyWrapped) {
      return sql;
    }
    switch (queryType) {
      case 'FUNCTION':
        switch (dbType) {
          case DbType.POSTGRESQL:
          case DbType.MYSQL:
          case DbType.MARIADB:
            return `SELECT ${trimmed}`;
          case DbType.MSSQL:
            return `SELECT ${trimmed}`;
          case DbType.ORACLE:
            return `SELECT ${trimmed} FROM DUAL`;
          default:
            return `SELECT ${trimmed}`;
        }
      case 'PROCEDURE':
        switch (dbType) {
          case DbType.POSTGRESQL:
          case DbType.MYSQL:
          case DbType.MARIADB:
            return `CALL ${trimmed}`;
          case DbType.MSSQL:
            return `EXEC ${trimmed}`;
          case DbType.ORACLE:
            return `BEGIN ${trimmed}; END;`;
          default:
            return `CALL ${trimmed}`;
        }
      default:
        return sql;
    }
  }

  private extractResultValue(result: {
    rows: unknown[];
  }): unknown {
    // Retourne la première ligne/valeur trouvée.
    // - Pour une ligne primitive (number/string/boolean/array) on renvoie la valeur.
    // - Pour un objet (ex: { val: 1 }), on extrait le premier champ numérique si disponible,
    //   sinon on retourne l'objet entier pour que le validation soit faite à l'appelant.
    // Cette méthode laisse la logique de validation (ex: conversion en number)
    // à l'appelant si nécessaire (ex: Monitoring qui attend un nombre).
    if (!result.rows?.length) {
      return null;
    }
    const first = result.rows[0];
    if (
      typeof first === 'number' ||
      typeof first === 'string' ||
      typeof first === 'boolean' ||
      Array.isArray(first)
    ) {
      return first;
    }
    if (typeof first === 'object' && first !== null) {
      const obj = first as Record<string, unknown>;
      // Essayer d'extraire la première valeur numérique de l'objet
      for (const value of Object.values(obj)) {
        if (typeof value === 'number') {
          return value;
        }
        // Si c'est une chaîne numérique, la retourner comme chaîne pour que l'appelant décide
        if (typeof value === 'string' && /^-?\d+\.?\d*$/.test(value)) {
          return value;
        }
      }
      // Si aucune valeur numérique n'est trouvée, retourner l'objet entier
      return obj;
    }
    return first;
  }

  private async runWithTimeout<T>(
    fn: () => Promise<T>,
    timeoutMs: number,
  ): Promise<T> {
    // Exécute la fonction asynchrone mais rejette si elle dépasse `timeoutMs`.
    // Important pour éviter que des appels bloquants monopolisent le pool.
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error('TIMEOUT'));
      }, timeoutMs);
      fn()
        .then((r) => {
          clearTimeout(timer);
          resolve(r);
        })
        .catch((e) => {
          clearTimeout(timer);
          reject(e);
        });
    });
  }

  private mapError(
    err: unknown,
    durationMs: number,
  ): Extract<QueryExecutionOutcome, { success: false }>['error'] {
    const message = err instanceof Error ? err.message : String(err);
    if (message === 'TIMEOUT') {
      // Erreur de timeout explicite
      return { code: 'TIMEOUT', message: 'Délai d\'exécution dépassé', durationMs };
    }
    if (
      message.includes('connect') ||
      message.includes('ECONNREFUSED') ||
      message.includes('ENOTFOUND')
    ) {
      return {
        code: 'ERREUR_CONNEXION',
        message,
        durationMs,
      };
    }
    if (message.includes('Driver') || message.includes('non supporté')) {
      return { code: 'ERREUR_DRIVER', message, durationMs };
    }
    return { code: 'ERREUR_SQL', message, durationMs };
  }

  private hashSql(sql: string): string {
    let hash = 0;
    for (let i = 0; i < sql.length; i++) {
      hash = (hash << 5) - hash + sql.charCodeAt(i);
      hash |= 0;
    }
    return String(hash);
  }
}
