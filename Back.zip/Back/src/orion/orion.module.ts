import { Module } from '@nestjs/common';
import { AppController } from 'src/app.controller';
import { AppService } from 'src/app.service';
import { CoreAccountService } from './services/core-account.service';
import { DateManagerFormatService } from 'src/common/class/date-format-manager.service';
import { BankHubController } from './controllers/bank-hub.controller';

@Module({
  imports: [],
  controllers:[BankHubController],
  providers: [CoreAccountService,DateManagerFormatService],
  exports: [CoreAccountService],
})
export class OrionModule {}
