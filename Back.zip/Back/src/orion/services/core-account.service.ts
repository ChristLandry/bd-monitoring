import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DateManagerFormatService } from 'src/common/class/date-format-manager.service';
import { Utils } from 'src/common/utils';
import { CoreAccountClient, KycAccountData } from 'src/orion/lib/core-account-client';

@Injectable()
export class CoreAccountService {
  private readonly coreAccountClient: CoreAccountClient;

  constructor(
    private readonly configService: ConfigService,

    private readonly dateManagerFormatService: DateManagerFormatService,
  ) {
    const clientDefaultSettings = {
      username: this.configService.get('WSO2_CORE_API_CONSUMER_KEY'),
      password: this.configService.get('WSO2_CORE_API_CONSUMER_SECRET'),
      baseUrl: this.configService.get('CORE_ACCOUNT_API_ENDPOINT'),
      authUrl: this.configService.get('WSO2_AUTH_ENDPOINT'),
      validateSSL: false,
      requester: this.configService.get('CORE_ACCOUNT_API_REQUESTER'),
      productPath: this.configService.get<string>('WSO2PRODUCT') || 'product-ereleve/v1',
    };
    this.coreAccountClient = CoreAccountClient.getClient({
      ...clientDefaultSettings,
      productPath: this.configService.get<string>('WSO2PRODUCT') || 'product-ereleve/v1',
      baseUrl: this.configService.get('CORE_ACCOUNT_API_ENDPOINT'),
    });
  }

  // Récupérer les transactions depuis ORION
  async getAccountTransactions(bankAccount: string, start: Date, end: Date) {
    try {
      //console.log('>>>>>>>>>>>>>>> getAccountTransactions start', start)
      //console.log('>>>>>>>>>>>>>>> getAccountTransactions end:', end)

      const apistart = this.dateManagerFormatService.getDateCoreFormat(start, 'yyyy-MM-dd');
      const apiend = this.dateManagerFormatService.getDateCoreFormat(end, 'yyyy-MM-dd');

      let trx = await this.coreAccountClient.getCustomerTransactionsReport(
        bankAccount,
        apistart,
        apiend
      );
      //console.log('Transactions retrieved:', trx);
      return trx
    } catch (error) {
      console.error('Error retrieving transactions:', error);
      throw error;
    }
  }

  // Récupérer le solde d'un compte à une date donnée
  async getBalanceAtDate(bankAccount: string, date: Date) {
    try {
      const apidate = this.dateManagerFormatService.getDateCoreFormat(date);
      // date = Utils.dateFormat(date, 'DD-MM-YYYY') || '';
      // console.log('Formatted date:', date);
      let trx = await this.coreAccountClient.getBalanceAtSpecificDate(
        bankAccount,
        apidate,
      );
      console.log(`Balance of account ${bankAccount} at ${date} retrieved:`, trx);
      return trx;
    } catch (error) {
      console.error(`Error retrieving balance at ${date} for account ${bankAccount}:`, error);
      throw error;
    }
  }

  async customerKYC(bankAccount: string): Promise<KycAccountData> {
    try {
      let trx = await this.coreAccountClient.getKYCByAccount(
        bankAccount);
      //console.log(`account kyc at ${bankAccount} retrieved:`, trx);
      return trx?.data;
    } catch (error) {
      /*console.error(
        `Error retrieving balance at ${date} for account ${bankAccount}:`,
        error,
      );*/
      throw error;
    }
  }


  async customerKYCBicrels(bankAccount: string) {
    try {
      let trx = await this.coreAccountClient.customerKYCBicrels(
        bankAccount);
      //console.log(`account kyc with bicrels at ${bankAccount} retrieved:`, trx);
      return trx?.data;
    } catch (error) {
      /*console.error(
        `Error retrieving balance at ${date} for account ${bankAccount}:`,
        error,
      );*/
      throw error;
    }
  }

  async clientAccounts(rootClient: string) {
    try {
      let trx = await this.coreAccountClient.clientAccounts(
        rootClient);
      // console.log(`Balance at ${date} retrieved:`, trx);
      return trx?.data;
    } catch (error) {
      /*console.error(
        `Error retrieving balance at ${date} for account ${bankAccount}:`,
        error,
      );*/
      throw error;
    }
  }


  async getDatOperec() {
    try {
      let dateInput = await this.coreAccountClient.getDatOperec();
      console.log('getDatOperec >>>>>>>>>>>>>>>>>>>', dateInput)
      return this.dateManagerFormatService.parseDate(dateInput)
    } catch (error) {
      /*console.error(
        `Error retrieving balance at ${date} for account ${bankAccount}:`,
        error,
      );*/
      throw error;
    }
  }


  async datOperDay() {
    try {
      let dateInput = await this.coreAccountClient.datOperDay();
      console.log('datOperDay >>>>>>>>>>>>>>>>>>>', dateInput)
      return this.dateManagerFormatService.parseDate(dateInput)
      //return await this.coreAccountClient.datOperDay();
    } catch (error) {
      console.error(
        `Error date oper day:`,
        error,
      );
      throw error;
    }
  }
}
