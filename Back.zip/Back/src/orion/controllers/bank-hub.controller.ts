import { Controller, Get, Param, Put, Body, Post, NotImplementedException, Query } from '@nestjs/common';
import { CoreAccountService } from '../services/core-account.service';

@Controller('bank-hub')
export class BankHubController {
    constructor(private readonly coreAccountService: CoreAccountService
    ) { }


    @Get('client-kyc/:bankAccount')
    async getCustomerKYC(@Param('bankAccount') bankAccount: string) {
        return await this.coreAccountService.customerKYC(bankAccount);
    }

    
    @Get('client-additionnels-kyc/:bankAccount')
    async customerKYCBicrels(@Param('bankAccount') bankAccount: string) {
        return await this.coreAccountService.customerKYCBicrels(bankAccount);
    }


    @Get('client-accounts/:rootClient')
    async getClientAccounts(@Param('rootClient') rootClient: string) {
        return await this.coreAccountService.clientAccounts(rootClient);
    }
}
