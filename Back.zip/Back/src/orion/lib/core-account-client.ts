import { ConfigService } from '@nestjs/config';
import { plainToClass } from 'class-transformer';
import {
  ApiClient,
  ClientOptions,
} from 'src/common/definitions/class/api-client';

export class KycAccountResponse {
  code: string;
  message: string;
  data: KycAccountData
}

export class KycAccountData {
  agence: string;
  client: string;
  accountNumber: string;
  nom: string;
  devise: string;
  ncg: string;
  libelleNcg: string;
  type: string;
  fonds: string;
  expl: string;
  bicrels: string;
  tel: string;
  email: string;
  payNais: string;
  payRes: string;
  datNais: string;
  idp: string;
  idm: string;
  jurLib1: string;
  sigle: string;
  objSoc: string;
  paysJur: string;
  paysExpl: string;
  adress: string;
  postal: string;
  ville: string;
  pays: string;
}

export class GetCustomerRIBResult {
  code: string;
  message: string;
  data: {
    accountNumber: string;
    agencyCode: string;
    clientName: string;
    ribKey: number;
    clientAddress: string;
    postalCode: string;
    codePostal: string;
    postalCity: string;
    country: string;
    codeBanque: string;
    swift: string;
    iban: string;
  };
}

export class ClientAccounts {
  code: string;
  message: string;
  data: ClientAccountData[];
}

export class ClientAccountData {
  accountNumber: string;
  type: string;
  typeName: string;
  key: string;
  devise: string;
  accountAgency: string;
  accountOpenDate: string;
  accountCloseDate: string | null;
  managerCode: string;
  iban: string;
}

export class CustomerKYC {
  code: string;
  message: string;
  data: {
    nomClient: string;
    categorieClient: string;
    nationaliteClient: string;
    paysResidenceClient: string;
    telephoneClient: string;
    denominationSociale: string | null;
    raisonSociale: string | null;
    identificationFiscale: string | null;
    identificationRccm: string | null;
    emailClient: string;
    adresseClient: string;
    codePostaleClient: string;
    identificationNationaleClient: string;
    numeroPasseport: string | null;
    genreClient: string;
    dateNaissanceClient: string;
    paysNaissanceClient: string;
    villeNaissanceClient: string;
    villeClient: string | null;
    nomMere: string | null;
    categorieEntreprise: string | null;
    codeActivite: string | null;
    iban: string;
    other: string;
    typeCompte: string;
    dateOuvertureCompte: string;
    telidp: string | null;
    telportidp: string | null;
    photoClient: string | null;
    ncg: string | null;
    datfrm: string | null;
  };
}

export class GetBalanceResult {
  code: string;
  message: string;
  data: {
    client: string;
    account: string;
    oldBalance: number;
    balance: number;
    overdrawValue: number;
    remainingBalance: number;
    ribKey: string;
    devise: string;
    agency: string;
    balanceDate: number;
    valueDate: string;
  };
}

export class GetBalanceAtSpecificDateResult {
  code: string;
  message: string;
  data: {
    balance: number;
  };
}

export class GetDatOperecResult {
  code: string;
  message: string;
  data: string;
}

export class BankTransaction {
  account: string;
  operationDate: Date;
  valueDate: Date;
  amount: number;
  credit: number;
  debit: number;
  label: string;
  operationCode: string;
  reference: string;
  relativeReference: string;
}

export class BankTransactionsReport {
  code: string;
  message: string;
  data: BankTransaction[] | null;
}

export class CoreAccountClientOptions extends ClientOptions {
  requester?: string = 'ERELEVE';
}

export class CoreAccountClient extends ApiClient {
  private productPath: string;
  private constructor(
    opts?: CoreAccountClientOptions) {
    super(opts);
    this.configureAxiosInstance(opts);
    this.productPath = opts?.productPath || 'product-ereleve/v1'
    //WSO2PRODUCT="product-ereleve"
  }

  /**
   * Obtenir une nouvelle instance de client
   * @param opts
   * @returns
   */
  static getClient(opts?: CoreAccountClientOptions) {
    //console.log(opts)
    return new CoreAccountClient(opts);
  }

  async getBalance(
    accountNo: string,
    requester?: string,
    url: string = `/${this.productPath}/account/balance/{accountNo}`,
  ) {
    const response = await this.axiosInstance.request<GetBalanceResult>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions).requester,
      },
      url: `${url.replaceAll('{accountNo}', accountNo)}`,
    });
    return response?.data;
  }

  async customerKYC(
    accountNo: string,
    requester?: string,
    url: string = `/${this.productPath}/account/signaletique/{accountNo}`,
  ) {
    const response = await this.axiosInstance.request<CustomerKYC>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions)?.requester,
      },
      url: `${url.replaceAll('{accountNo}', accountNo)}`,
    });

    //console.log(`account kyc at ${accountNo} retrieved:`, response?.data);
    return response?.data;
  }


  async customerKYCBicrels(
    accountNo: string,
    requester?: string,
    url: string = `/${this.productPath}/account/{accountNo}`,
  ) {
    const response = await this.axiosInstance.request<any>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions)?.requester,
      },
      url: `${url.replaceAll('{accountNo}', accountNo)}`,
    });

    //console.log(`account kyc at ${accountNo} retrieved:`, response?.data);
    return response?.data;
  }

  async getKYCByAccount(
    accountNo: string,
    requester?: string,
    url: string = `/${this.productPath}/account/{accountNo}/informations`,
  ) {
    const response = await this.axiosInstance.request<KycAccountResponse>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions)?.requester,
      },
      url: `${url.replaceAll('{accountNo}', accountNo)}`,
    });

    //console.log(`account kyc at ${accountNo} retrieved:`, response?.data);
    //let date = response?.data.data;
    return response?.data
  }

  async getCustomerTransactionsReport(
    accountNo: string,
    start?: string,
    end?: string,
    requester?: string,
    url: string = `/${this.productPath}/client/account-operations/{accountNo}/{start}/{end}`,
  ) {

    //console.log('===> start:', start);
    //console.log('===> end:', end);

    try {
      const response = await this.axiosInstance.request<any>(
        {
          headers: await this.getDefaultHeaders(),
          method: 'GET',
          params: {
            requester:
              requester ||
              (this.options as CoreAccountClientOptions)?.requester,
          },
          url: `${url
            .replace('{accountNo}', accountNo)
            .replace('{start}', start || '')
            .replace('{end}', end || '')}`,
        },
      );
      return response?.data.data;
    } catch (error) {
      console.error('Error in getCustomerTransactionsReport:', error);
      //  console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> response:', error.response.status);
      if (error.response.status == 404) {
        // console.log(`>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>`);
        return []
      }
    }
    return null;
  }

  async getCustomerRIB(
    accountNo: string,
    requester?: string,
    url: string = `/${this.productPath}/account/rib/{accountNo}`,
  ) {
    const response = await this.axiosInstance.request<GetCustomerRIBResult>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions)?.requester,
      },
      url: `${url.replaceAll('{accountNo}', accountNo)}`,
    });
    //console.log(response?.data)
    return response?.data;
  }

  async getBalanceAtSpecificDate(
    accountNo: string,
    requestedDate: Date | string,
    requester?: string,
    url: string = `/${this.productPath}/account/balance-at-date/{accountNo}/{date}`,
  ) {
    try {
      // const parsedDate = requestedDate instanceof Date ? requestedDate.getDay()+'-'+requestedDate.getMonth()+'-'+requestedDate.getFullYear() : requestedDate
      /*
        console.log("requestedDate",requestedDate)
        console.log("parsedDate:",parsedDate)
        console.log("acocuntNo",accountNo)
        */
      const response =
        await this.axiosInstance.request<GetBalanceAtSpecificDateResult>({
          headers: await this.getDefaultHeaders(),
          method: 'GET',
          params: {
            requester:
              requester || (this.options as CoreAccountClientOptions).requester,
          },
          url: `${url.replaceAll('{accountNo}', accountNo).replaceAll('{date}', requestedDate.toString())}`,
        });
      /* console.log(
         '>>>>>>>>>>>>>>>>getBalanceAtSpecificDate response:',
         response,
       );*/
      return response?.data?.data?.balance;
    } catch (error) {
      console.error('Error in getBalanceAtSpecificDate:', error);
      throw error;
    }
  }

  async getDatOperec(url: string =
    `/${this.productPath}/transaction/accounting-date/?requester=ERELEVE&type=previous`) {
    try {
      const response = await this.axiosInstance.request<GetDatOperecResult>({
        headers: await this.getDefaultHeaders(),
        method: 'GET',
        url: url,
      });
      //console.log('datOperDay response:', response?.data.data);
      return response?.data.data;
    } catch (error) {
      console.error('Error in getOperec:', error);
      throw error;
    }
  }

  async datOperDay(url: string =
    `/${this.productPath}/transaction/accounting-date/?requester=ERELEVE&type=current`) {
    try {
      const response = await this.axiosInstance.request<GetDatOperecResult>({
        headers: await this.getDefaultHeaders(),
        method: 'GET',
        url: url,
      });
      console.log('datOperDay response:', response?.data.data);
      return response?.data.data;
    } catch (error) {
      console.error('Error in datOperDay:', error);
      throw error;
    }
  }


  async clientAccounts(clientid: string,
    requester?: string,
    url: string = `/${this.productPath}/client/accounts-list/{clientid}`,
  ) {
    //?requester=${this.requestId}
    const response = await this.axiosInstance.request<ClientAccounts>({
      headers: await this.getDefaultHeaders(),
      method: 'GET',
      params: {
        requester:
          requester || (this.options as CoreAccountClientOptions)?.requester,
      },
      url: `${url.replaceAll('{clientid}', clientid)}`,
    });
    return plainToClass(ClientAccounts, response.data);
    //return response?.data;
  }

  convertToDateString(date: Date) {
    return date.getDay() + '-' + date.getMonth() + '-' + date.getFullYear();
  }
}
