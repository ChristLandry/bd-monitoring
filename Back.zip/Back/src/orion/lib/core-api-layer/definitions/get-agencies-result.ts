

export class GetAgenciesResult {
    code: string
    message: string
    data: {
        content: {
            code: string,
            name: string,
            city: string,
            longitude?: string|null,
            latitude?: string|null,
            lastUpdate: Date,
            contact?: string|null,
            adresse?: string|null,
            horaireOuvertureOrdinaire?: string|null,
            horaireOuvertureDimanche?: string|null,
            horaireOuvertureSamedi?: string|null
        }[]
        pageable: {
            pageNumber: number,
            pageSize: number,
            offset: number,
            paged: boolean,
            unpaged: boolean
        },
        last: boolean,
        totalElements: number,
        totalPages: number,
        size: number,
        number: number
    }
}