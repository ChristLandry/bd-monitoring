

export class GetBankPersonalResult {
    code: string
    message: string
    data: {
            nom: string,
            uname: string,
            agence: string
    }
}