
export class GetDABResult {
    code: string
    message: string
    data: {
        content: {
            lastUpdate: Date,
            atmId: string,
            name: string,
            state: string,
            longitude: string,
            latitude: string,
            zone: string
        }[]
        page: number,
        size: number,
        totalElements: number,
        totalPages: number,
        first: boolean,
        last: boolean,
        numberOfElements: number,
        empty: boolean,
        nextPage: number,
        previousPage: number
    }
}