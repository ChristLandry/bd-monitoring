import { AuthentificationResponse } from 'src/common/definitions/class/authentification-response';
import { GenericAPIClient } from 'src/common/definitions/class/generic-api-client';
import ClientOptions from 'src/common/definitions/class/client-options';
import { AuthDto } from 'src/administration/definitions/dto/auth/auth.request.dto';
import { UserResponseDto } from 'src/administration/definitions/dto/auth/auth.response.dto';
import { plainToClass } from 'class-transformer';
const qs = require('qs');
const https = require('https');

export class BNICoreAPIClient extends GenericAPIClient {
  private productPath: string;
  private constructor(opts?: ClientOptions) {
    super(opts);
    this.productPath = opts?.productPath || 'product-bni/v1'
  }

  /**
   * Obtenir une nouvelle instance de client
   * @param opts
   * @returns
   */
  static getClient(opts?: ClientOptions) {
    return new BNICoreAPIClient(opts);
  }

  override async authenticate(
    clientId?: string,
    clientSecret?: string,
    url: string = 'apim/oauth2/token',
  ): Promise<AuthentificationResponse> {
    return super.authenticate(clientId, clientSecret, url);
  }

  async login(input: AuthDto): Promise<UserResponseDto | null> {
    try {
      await this.authenticate();
      let url: string = `/${this.productPath}/ldap/login?requester=ERELEVE`;

      const response = await this.axiosInstance.request<UserResponseDto>({
        method: 'POST',
        headers: { Authorization: `Bearer ${this.accessToken}` },
        data: input,
        url: url,
      });
      console.log('>>>>>>>>>>>>>>>>>>  Auth', response);
      if (response.status == 200) {
        return response.data;
      } else {
        return null;
      }
    } catch (error) {
      console.log('>>>>>>>>>>>>>>>>>>  Auth', error || error.message);
      return null;
    }
  }

  async getUserLdap(login: string): Promise<UserResponseDto | null> {
    try {
      await this.authenticate();
      let url: string = `/${this.productPath}/ldap/users/${login}?requester=ERELEVE&include_rh=false&include_orion=true`;

      const response = await this.axiosInstance.request<any>({
        method: 'GET',
        headers: { Authorization: `Bearer ${this.accessToken}` },
        url: url,
      });
      console.log('>>>>>>>>>>>>>>>>>>  Auth', response);
      if (response.status == 200) {
        return {
          login: response.data.login,
          username: response.data.username,
          nom: response.data.nom,
          prenoms: response.data.prenoms,
          departement: response.data.departement,
          situationGeo: response.data.situationGeo,
          email: response.data.email,
          fonction: response.data.fonction,
          telBur: response.data.telBur,
          id: response.data.id,
          service: response.data.service,
          direction: response.data.direction,
          codeExploitant: response.data.orion?.codeExploitant || '' 
        } as UserResponseDto;
        //return response.data;
      } else {
        return null;
      }
    } catch (error) {
      console.log('>>>>>>>>>>>>>>>>>>  Auth', error || error.message);
      return null;
    }
  }
}
