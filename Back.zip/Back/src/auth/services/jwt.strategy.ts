import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { JwtPayload } from '../../common/decorators/current-user.decorator';
import { UsersService } from '../../users/services/users.service';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  /**
   * Stratégie JWT utilisée par Passport pour authentifier les requêtes.
   * - Extrait le token depuis l'en-tête Bearer
   * - Vérifie la signature via `JWT_SECRET` et la date d'expiration
   * - `validate` récupère l'utilisateur et assure que le compte est actif
   */
  constructor(
    config: ConfigService,
    private readonly usersService: UsersService,
  ) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: config.get<string>('JWT_SECRET', 'dev-secret'),
    });
  }

  async validate(payload: JwtPayload): Promise<JwtPayload> {
    const user = await this.usersService.getOrFail(payload.sub);
    if (!user.active) {
      throw new UnauthorizedException('Compte désactivé');
    }
    return payload;
  }
}
