import { ThresholdEvaluator } from './threshold-evaluator.class';
import { ThresholdOperator } from '../model/threshold-operator.enum';

// ─────────────────────────────────────────────────────────────────────────────
// Comparaisons NUMÉRIQUES
// (seuil = chaîne représentant un nombre ; valeur retournée = nombre ou string numérique)
// ─────────────────────────────────────────────────────────────────────────────
describe('ThresholdEvaluator – comparaison numérique', () => {
  describe('opérateur >', () => {
    it('101 > "100" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(101, '100', ThresholdOperator.GT)).toBe(true);
    });
    it('100 > "100" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(100, '100', ThresholdOperator.GT)).toBe(false);
    });
    it('"101" (string) > "100" → true (les deux sont numériques)', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('101', '100', ThresholdOperator.GT)).toBe(true);
    });
  });

  describe('opérateur <', () => {
    it('5 < "10" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(5, '10', ThresholdOperator.LT)).toBe(true);
    });
    it('15 < "10" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(15, '10', ThresholdOperator.LT)).toBe(false);
    });
  });

  describe('opérateur =', () => {
    it('42 = "42" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(42, '42', ThresholdOperator.EQ)).toBe(true);
    });
    it('42 = "43" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(42, '43', ThresholdOperator.EQ)).toBe(false);
    });
  });

  describe('opérateur >=', () => {
    it('100 >= "100" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(100, '100', ThresholdOperator.GTE)).toBe(true);
    });
    it('5 >= "10" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(5, '10', ThresholdOperator.GTE)).toBe(false);
    });
    it('5 <= "10" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(5, '10', ThresholdOperator.LTE)).toBe(true);
    });
  });

  describe('opérateur !=', () => {
    it('99 != "100" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(99, '100', ThresholdOperator.NEQ)).toBe(true);
    });
    it('100 != "100" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(100, '100', ThresholdOperator.NEQ)).toBe(false);
    });
  });

  describe('décimaux', () => {
    it('3.6 > "3.5" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded(3.6, '3.5', ThresholdOperator.GT)).toBe(true);
    });
    it('"3.14" = "3.14" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('3.14', '3.14', ThresholdOperator.EQ)).toBe(true);
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Comparaisons LEXICOGRAPHIQUES
// (seuil = chaîne non-numérique OU valeur retournée = chaîne non-numérique)
// ─────────────────────────────────────────────────────────────────────────────
describe('ThresholdEvaluator – comparaison lexicographique', () => {
  describe('opérateur = sur chaînes', () => {
    it('"ERREUR" = "ERREUR" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('ERREUR', 'ERREUR', ThresholdOperator.EQ)).toBe(true);
    });
    it('"OK" = "ERREUR" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('OK', 'ERREUR', ThresholdOperator.EQ)).toBe(false);
    });
  });

  describe('opérateur != sur chaînes', () => {
    it('"KO" != "OK" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('KO', 'OK', ThresholdOperator.NEQ)).toBe(true);
    });
    it('"OK" != "OK" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('OK', 'OK', ThresholdOperator.NEQ)).toBe(false);
    });
  });

  describe('opérateur > sur chaînes (ordre lexicographique)', () => {
    it('"beta" > "alpha" → true', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('beta', 'alpha', ThresholdOperator.GT)).toBe(true);
    });
    it('"alpha" > "beta" → false', () => {
      expect(ThresholdEvaluator.isThresholdExceeded('alpha', 'beta', ThresholdOperator.GT)).toBe(false);
    });
  });

  describe('seuil non-numérique force le mode lexicographique', () => {
    it('valeur numérique 42 vs seuil "ABC" → comparaison lexicographique', () => {
      // "42".localeCompare("ABC") < 0 → 42 < "ABC" → true
      expect(ThresholdEvaluator.isThresholdExceeded(42, 'ABC', ThresholdOperator.LT)).toBe(true);
    });
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// Cas limites
// ─────────────────────────────────────────────────────────────────────────────
describe('ThresholdEvaluator – cas limites', () => {
  it('seuil "0" et valeur 0 → = true', () => {
    expect(ThresholdEvaluator.isThresholdExceeded(0, '0', ThresholdOperator.EQ)).toBe(true);
  });

  it('valeur négative -5 < "0" → true', () => {
    expect(ThresholdEvaluator.isThresholdExceeded(-5, '0', ThresholdOperator.LT)).toBe(true);
  });

  it('opérateur inconnu → false', () => {
    expect(
      ThresholdEvaluator.isThresholdExceeded(100, '50', 'INVALID' as ThresholdOperator),
    ).toBe(false);
  });

  it('valeur vide "" vs seuil "ERREUR" → = false', () => {
    expect(ThresholdEvaluator.isThresholdExceeded('', 'ERREUR', ThresholdOperator.EQ)).toBe(false);
  });
});
