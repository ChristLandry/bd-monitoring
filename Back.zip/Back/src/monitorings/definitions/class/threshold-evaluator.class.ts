import { ThresholdOperator } from '../model/threshold-operator.enum';

/**
 * Tente de convertir une valeur en nombre fini.
 * Retourne null si la valeur n'est pas un nombre valide (NaN, Infinity, null, '').
 */
function toFiniteNumber(v: unknown): number | null {
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'string' && v.trim() !== '') {
    const n = Number(v.trim());
    return Number.isFinite(n) ? n : null;
  }
  return null;
}

export class ThresholdEvaluator {
  /**
   * Évalue si `rawValue` dépasse le seuil `threshold` avec l'opérateur donné.
   *
   * Règles de comparaison :
   * - Si `threshold` représente un entier/décimal ET que `rawValue` est aussi
   *   convertible en nombre → comparaison **numérique** (ex: 101 > 100).
   * - Sinon → comparaison **lexicographique** (ex: "ERREUR" = "ERREUR").
   */
  static isThresholdExceeded(
    rawValue: unknown,
    threshold: string,
    operator: ThresholdOperator,
  ): boolean {
    const numThreshold = toFiniteNumber(threshold);
    const numValue     = toFiniteNumber(rawValue);

    if (numThreshold !== null && numValue !== null) {
      return ThresholdEvaluator.compareNumeric(numValue, numThreshold, operator);
    }

    // Fallback : comparaison lexicographique
    const strValue = String(rawValue ?? '');
    return ThresholdEvaluator.compareString(strValue, threshold, operator);
  }

  private static compareNumeric(
    value: number,
    threshold: number,
    operator: ThresholdOperator,
  ): boolean {
    switch (operator) {
      case ThresholdOperator.GT:  return value > threshold;
      case ThresholdOperator.LT:  return value < threshold;
      case ThresholdOperator.EQ:  return value === threshold;
      case ThresholdOperator.GTE: return value >= threshold;
      case ThresholdOperator.LTE: return value <= threshold;
      case ThresholdOperator.NEQ: return value !== threshold;
      default: return false;
    }
  }

  private static compareString(
    value: string,
    threshold: string,
    operator: ThresholdOperator,
  ): boolean {
    const cmp = value.localeCompare(threshold);
    switch (operator) {
      case ThresholdOperator.GT:  return cmp > 0;
      case ThresholdOperator.LT:  return cmp < 0;
      case ThresholdOperator.EQ:  return cmp === 0;
      case ThresholdOperator.GTE: return cmp >= 0;
      case ThresholdOperator.LTE: return cmp <= 0;
      case ThresholdOperator.NEQ: return cmp !== 0;
      default: return false;
    }
  }
}
