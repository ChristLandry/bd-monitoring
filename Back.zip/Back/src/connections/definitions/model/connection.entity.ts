import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { DbType } from './db-type.enum';
import { Environment } from './environment.enum';
import { SqlQueryEntity } from '../../../queries/definitions/model/sql-query.entity';

@Entity('connections')
export class ConnectionEntity {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 255 })
  label: string;

  @Column({ type: 'enum', enum: DbType })
  type: DbType;

  @Column({ length: 512 })
  host: string;

  @Column({ type: 'int', nullable: true })
  port: number | null;

  /**
   * Nom de la base de données.
   * Pour Oracle, laisser null et renseigner serviceName à la place.
   * type: 'varchar' est explicite car TypeScript infère string | null → Object
   * via reflect-metadata, ce que TypeORM ne sait pas mapper.
   */
  @Column({ type: 'varchar', length: 255, nullable: true })
  database: string | null;

  /**
   * SERVICE_NAME Oracle — remplace `database` pour les connexions Oracle.
   * Exemple : DBBNIAPP
   */
  @Column({ type: 'varchar', length: 255, nullable: true, name: 'service_name' })
  serviceName: string | null;

  /**
   * Type de serveur Oracle : DEDICATED (défaut) ou SHARED.
   * Correspond à CONNECT_DATA.SERVER dans le descripteur TNS.
   */
  @Column({
    type: 'varchar',
    length: 20,
    nullable: true,
    name: 'oracle_server_type',
    default: 'DEDICATED',
  })
  oracleServerType: 'DEDICATED' | 'SHARED' | null;

  /**
   * Nom de l'instance SQL Server nommée (ex : SQLSERVER22 dans BNILPT147201\SQLSERVER22).
   * Quand renseigné, le port fixe est ignoré : tedious interroge le SQL Server Browser
   * (UDP 1434) pour découvrir le port dynamique de l'instance.
   * Peut aussi être extrait automatiquement si host contient un '\'.
   */
  @Column({ type: 'varchar', length: 128, nullable: true, name: 'instance_name' })
  instanceName: string | null;

  /**
   * Trusted Connection MSSQL (Trusted_Connection=True/False).
   * Si true, l'authentification Windows est utilisée (pas de user/password).
   */
  @Column({ default: false, name: 'trusted_connection' })
  trustedConnection: boolean;

  @Column({ length: 255 })
  username: string;

  @Column({ type: 'text' })
  passwordEncrypted: string;

  @Column({ type: 'enum', enum: Environment, default: Environment.DEV })
  environment: Environment;

  @Column({ default: false })
  sslEnabled: boolean;

  @Column({ type: 'jsonb', nullable: true })
  options: Record<string, unknown> | null;

  @Column({ default: true })
  actif: boolean;

  @CreateDateColumn({ name: 'date_creation' })
  dateCreation: Date;

  @OneToMany(() => SqlQueryEntity, (q) => q.connection)
  queries: SqlQueryEntity[];
}
