import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import {
  IsBoolean,
  IsEnum,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsObject,
  IsOptional,
  IsString,
  MaxLength,
  Min,
} from 'class-validator';
import { DbType } from '../model/db-type.enum';
import { Environment } from '../model/environment.enum';

export class CreateConnectionDto {
  @ApiProperty({ example: 'Oracle BNI Production' })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  label: string;

  @ApiProperty({ enum: DbType, example: DbType.ORACLE })
  @IsEnum(DbType)
  type: DbType;

  @ApiProperty({
    example: '10.201.4.4',
    description: 'Adresse IP ou hostname du serveur (HOST dans le descripteur Oracle, Server pour MSSQL)',
  })
  @IsString()
  @IsNotEmpty()
  host: string;

  @ApiPropertyOptional({
    example: 1521,
    description:
      'Port de connexion (défaut Oracle : 1521, MSSQL : 1433, PostgreSQL : 5432). ' +
      'Pour une instance nommée MSSQL, laisser vide : le port est découvert via SQL Server Browser.',
  })
  @IsOptional()
  @IsInt()
  @Min(1)
  port?: number;

  @ApiPropertyOptional({
    example: 'GERE',
    description:
      'Nom de la base de données. Pour Oracle, laisser vide et utiliser serviceName à la place.',
  })
  @IsOptional()
  @IsString()
  database?: string;

  // ─── Champs spécifiques Oracle ──────────────────────────────────────────────

  @ApiPropertyOptional({
    example: 'DBBNIAPP',
    description:
      'SERVICE_NAME Oracle — remplace database pour les connexions Oracle. ' +
      'Exemple extrait de : CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=DBBNIAPP)',
  })
  @IsOptional()
  @IsString()
  @MaxLength(255)
  serviceName?: string;

  @ApiPropertyOptional({
    enum: ['DEDICATED', 'SHARED'],
    default: 'DEDICATED',
    description:
      'Type de serveur Oracle : DEDICATED (connexion dédiée, recommandé) ou SHARED. ' +
      'Correspond à CONNECT_DATA=(SERVER=DEDICATED) dans le descripteur TNS.',
  })
  @IsOptional()
  @IsIn(['DEDICATED', 'SHARED'])
  oracleServerType?: 'DEDICATED' | 'SHARED';

  // ─── Champs spécifiques MSSQL ───────────────────────────────────────────────

  @ApiPropertyOptional({
    example: 'SQLSERVER22',
    description:
      'Nom de l\'instance SQL Server nommée. ' +
      'Exemple : pour "BNILPT147201\\SQLSERVER22", renseigner host="BNILPT147201" et instanceName="SQLSERVER22". ' +
      'Accepte aussi le format tout-en-un dans host : "BNILPT147201\\SQLSERVER22". ' +
      'Quand instanceName est présent, le port est ignoré (découverte via SQL Server Browser UDP 1434).',
  })
  @IsOptional()
  @IsString()
  @MaxLength(128)
  instanceName?: string;

  @ApiPropertyOptional({
    default: false,
    description:
      'Trusted_Connection MSSQL. Si true, authentification Windows intégrée ' +
      '(Trusted_Connection=True). Si false, user id + password sont utilisés.',
  })
  @IsOptional()
  @IsBoolean()
  trustedConnection?: boolean;

  // ─── Champs communs ─────────────────────────────────────────────────────────

  @ApiProperty({
    example: 'wallet',
    description: 'Identifiant (user id / User Id / username selon le SGBD)',
  })
  @IsString()
  @IsNotEmpty()
  username: string;

  @ApiProperty({ example: 'Bni_1234567890' })
  @IsString()
  @IsNotEmpty()
  password: string;

  @ApiPropertyOptional({ enum: Environment, default: Environment.DEV })
  @IsOptional()
  @IsEnum(Environment)
  environment?: Environment;

  @ApiPropertyOptional({ default: false })
  @IsOptional()
  @IsBoolean()
  sslEnabled?: boolean;

  @ApiPropertyOptional({
    type: 'object',
    additionalProperties: true,
    description: 'Options avancées passées directement au driver (ex: { uri } pour MongoDB)',
  })
  @IsOptional()
  @IsObject()
  options?: Record<string, unknown>;
}
