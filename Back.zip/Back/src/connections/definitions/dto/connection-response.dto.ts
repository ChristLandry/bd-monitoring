import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { DbType } from '../model/db-type.enum';
import { Environment } from '../model/environment.enum';
import { ConnectionEntity } from '../model/connection.entity';

export class ConnectionResponseDto {
  @ApiProperty()
  id: string;

  @ApiProperty()
  label: string;

  @ApiProperty({ enum: DbType })
  type: DbType;

  @ApiProperty()
  host: string;

  @ApiPropertyOptional({
    description: 'Port (null si instance nommée MSSQL — découverte via SQL Browser)',
  })
  port: number | null;

  @ApiPropertyOptional({
    description: 'Nom de la base (null pour Oracle — voir serviceName)',
  })
  database: string | null;

  @ApiPropertyOptional({
    description: 'SERVICE_NAME Oracle (CONNECT_DATA)',
  })
  serviceName: string | null;

  @ApiPropertyOptional({
    enum: ['DEDICATED', 'SHARED'],
    description: 'Type de serveur Oracle (CONNECT_DATA.SERVER)',
  })
  oracleServerType: string | null;

  @ApiPropertyOptional({
    description: 'Instance nommée SQL Server (ex: SQLSERVER22 dans BNILPT147201\\SQLSERVER22)',
  })
  instanceName: string | null;

  @ApiProperty({
    description: 'Trusted_Connection MSSQL (authentification Windows)',
  })
  trustedConnection: boolean;

  @ApiProperty()
  username: string;

  @ApiProperty({ enum: Environment })
  environment: Environment;

  @ApiProperty()
  sslEnabled: boolean;

  @ApiPropertyOptional()
  options?: Record<string, unknown> | null;

  @ApiProperty()
  actif: boolean;

  @ApiProperty()
  dateCreation: Date;

  static fromEntity(entity: ConnectionEntity): ConnectionResponseDto {
    const dto = new ConnectionResponseDto();
    dto.id = entity.id;
    dto.label = entity.label;
    dto.type = entity.type;
    dto.host = entity.host;
    dto.port = entity.port;
    dto.database = entity.database;
    dto.serviceName = entity.serviceName;
    dto.oracleServerType = entity.oracleServerType;
    dto.instanceName = entity.instanceName;
    dto.trustedConnection = entity.trustedConnection;
    dto.username = entity.username;
    dto.environment = entity.environment;
    dto.sslEnabled = entity.sslEnabled;
    dto.options = entity.options;
    dto.actif = entity.actif;
    dto.dateCreation = entity.dateCreation;
    return dto;
  }
}

export class ConnectionTestResponseDto {
  @ApiProperty({ example: true })
  success: boolean;

  @ApiProperty({ example: 42 })
  responseTimeMs: number;

  @ApiPropertyOptional({ example: 'PostgreSQL 16.2' })
  serverVersion?: string;

  @ApiPropertyOptional()
  message?: string;
}
