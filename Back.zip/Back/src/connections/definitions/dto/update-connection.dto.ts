import { PartialType } from '@nestjs/swagger';
import { CreateConnectionDto } from './create-connection.dto';

/**
 * Tous les champs de CreateConnectionDto deviennent optionnels.
 * `password` est inclus : s'il est fourni, il sera re-chiffré côté service.
 */
export class UpdateConnectionDto extends PartialType(CreateConnectionDto) {}
