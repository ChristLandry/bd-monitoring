import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { NotificationChannel } from '../../monitorings/definitions/model/notification-channel.enum';
import { ContactGroupEntity } from '../../contact-groups/definitions/model/contact-group.entity';
import { MonitoringEntity } from '../../monitorings/definitions/model/monitoring.entity';
import FormData = require("form-data");
import * as https from "https";
import axios from "axios";

export interface AlertPayload {
  monitoring: MonitoringEntity;
  /** Valeur numérique retournée par la requête (null si la valeur est textuelle) */
  valeur: number | null;
  /** Seuil de non-acceptation (chaîne : peut être numérique "100" ou textuelle "ERREUR") */
  seuil: string;
  dashboardUrl: string;
  resolved?: boolean;
}

@Injectable()
export class NotificationDeliveryService {
  private readonly logger = new Logger(NotificationDeliveryService.name);

  constructor(private readonly config: ConfigService) {
  }

  async send(
    channel: NotificationChannel,
    group: ContactGroupEntity,
    payload: AlertPayload,
  ): Promise<void> {
    const subject = payload.resolved
      ? `[RÉSOLU] ${payload.monitoring.label}`
      : `[ALERTE ${payload.monitoring.priorite}] ${payload.monitoring.label}`;
    const body = this.buildBody(payload);

    const emails = group.members
      .map((m) => m.email)
      .filter((e): e is string => !!e);

    if (
      channel === NotificationChannel.MAIL ||
      channel === NotificationChannel.MAIL_SMS
    ) {
      for (const to of emails) {
        try {
          await this.sendMail({
            from: this.config.get<string>('MAIL_FROM') ?? 'DB MONITORING <messaging.gateway@bni.ci>',
            to: to,
            subject,
            html: body
          });
        } catch (err) {
          this.logger.error(`Échec email vers ${to}`, err);
        }
      }
    }

    if (
      channel === NotificationChannel.SMS ||
      channel === NotificationChannel.MAIL_SMS
    ) {
      const phones = group.members
        .map((m) => m.phone)
        .filter((p): p is string => !!p);
      for (const phone of phones) {
        await this.sendSms(phone, body);
      }
    }
  }

  private buildBody(payload: AlertPayload): string {
    return [
       `<p>Merci de recevoir la notification relative au monitoring: <strong>${payload.monitoring.description ?? payload.monitoring.label}</strong></p>`,
      `<p>Valeur de la requête:<strong> ${payload.valeur}</strong></p>`,
      `<p>Seuil de non acceptation: <strong>${payload.seuil}</strong></p>`,
      `<p>Le résultat de la comparaison est:<strong> ${payload.valeur} ${payload.monitoring.operateurSeuil} ${payload.seuil}</strong></p>`,
      `<p>Si vous avez intégré une requête de correction elle sera exécutée : ${payload.monitoring.correctionQuery != undefined ? payload.monitoring.correctionQuery:''}</p>`,
      `<p>Date de génération de la notification: ${new Date().toISOString()}</p>`,
      `<p>Dashboard: ${payload.dashboardUrl}</p>`,
      '<p>Veuillez ne pas répondre à ce message.</p>'
    ].join('\n');
  }

  private async sendSms(phone: string, body: string): Promise<void> {
    const sid = this.config.get('TWILIO_ACCOUNT_SID');
    if (!sid) {
      this.logger.warn(`SMS non configuré — message pour ${phone}: ${body.slice(0, 80)}`);
      return;
    }
    this.logger.log(`SMS envoyé à ${phone} (Twilio)`);
  }

  private async sendMail(options: {
    from: string;
    to: string | string[];
    subject: string;
    html: string;
  }): Promise<any> {

    try {
      const { from, to, subject, html } = options;

      const apiUrl =
        this.config.get<string>('MAIL_API_URL') ??
        'https://messaging-gateway.dev.bni/email/messages';

      const appId =
        this.config.get<string>('MAIL_API_APP_ID') ??
        '860711c7-e3d3-4057-b513-018c4138bde2';

      const toArray = Array.isArray(to)
        ? to
        : (to as string).split(',').map(e => e.trim()).filter(e => e.length > 0);

      const formData = new FormData();

      // Message JSON
      formData.append(
        'message',
        JSON.stringify({ from, to: toArray, subject, html }),
      );


      const httpsAgent = new https.Agent({ rejectUnauthorized: false });

      const response = await axios.post(apiUrl, formData, {
        maxBodyLength: Infinity,
        maxContentLength: Infinity,
        headers: {
          'x-app-id': appId,
          ...formData.getHeaders(),
        },
        httpsAgent,
        timeout: 30000,
      });
      this.logger.log(`Mail envoyé à ${toArray.join(', ')} via ${apiUrl} — status ${response.status}`);
      return response.data;

    } catch (error) {
      console.error('Error in sendMail:', error);
      return error;
    }
  }
}
