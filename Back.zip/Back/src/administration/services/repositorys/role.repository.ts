import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Menu } from "src/administration/entitys/menu.entity";
import { Role_Menus } from "src/administration/entitys/role-menus.entity";
import { Role } from "src/administration/entitys/role.entity";
import { Repository, FindOptionsRelations } from "typeorm";

@Injectable()
export class RoleRepository{
 constructor(
    @InjectRepository(Role)
    private repo: Repository<Role>,
  ) {}

  /**
   * Enregistrer une nouvelle transaction
   * @param data
   * @returns
   */
  async create(data: Partial<Role>): Promise<Role> {
    console.log('>>>>>>>>>>>>>>>>>>>>  create', data);
    return this.repo.save({ ...data });
  }

  async update(id: string, data: Partial<Role>) {
    return this.repo.update({ id: id }, data);
  }

  async findAll(): Promise<Role[]> {
    return this.repo.find();
  }

  async findOne(id: string): Promise<Role | null> {
    return this.repo.findOne({ where: { id: id } });
  }
    async findOneWithMenu(id: string): Promise<Role | null> {
    return this.repo.findOne({ where: { id: id } , 
     relations: ['role_Menus', 'role_Menus.menu'],});
  }
    async findOneByLabel(label: string): Promise<Role | null> {
      return this.repo.findOne({ where: { label: label } });
    }

}