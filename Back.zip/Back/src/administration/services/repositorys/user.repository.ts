import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Users } from "src/administration/entitys/user.entity";
import { Repository, FindOptionsRelations, FindOptionsWhere } from "typeorm";

@Injectable()
export class UserRepository{
 constructor(
    @InjectRepository(Users)
    private repo: Repository<Users>,
  ) {}

  /**
   * Enregistrer une nouvelle transaction
   * @param data
   * @returns
   */
  async create(data: Partial<Users>): Promise<Users> {
    console.log('>>>>>>>>>>>>>>>>>>>>  create', data);
    return this.repo.save({ ...data });
  }

  async update(id: string, data: Partial<Users>) {
    return this.repo.update({ id: id }, data);
  }

  async findAll(): Promise<Users[]> {
    return this.repo.find();
  }

  async findOne(id: string,relations: FindOptionsRelations<Users> = { role: true },): Promise<Users | null> {
    return this.repo.findOne({ where: { id: id } , relations: relations});
  }

  async findOneByMatricule(login: string,relations: FindOptionsRelations<Users> = { role: true }): Promise<Users | null> {
    return this.repo.findOne({ where: { login: login }, relations: relations });
  }
}