import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Menu } from 'src/administration/entitys/menu.entity';
import { Role_Menus } from 'src/administration/entitys/role-menus.entity';
import { Role } from 'src/administration/entitys/role.entity';
import { Repository } from 'typeorm';

@Injectable()
export class Role_MenuRepository {
  constructor(
    @InjectRepository(Role_Menus)
    private repoRole_Menus: Repository<Role_Menus>,
  ) {}

  create(role: Role, menu: Menu) {
    return this.repoRole_Menus.create({
      role: role, // tableau
      menu: menu,
    });
  }

  async save(newRelation: Role_Menus) {
    return await this.repoRole_Menus.save(newRelation);
  }

  async update(newRelation:Role_Menus) {
    return await this.repoRole_Menus.update(newRelation.id,newRelation);
  }

  async getRole_Menu(role: Role, menu: Menu) {
    return await this.repoRole_Menus.findOne({
      where: { role: role, menu: menu },
    });
  }

  async delete(id: string) {
    await this.repoRole_Menus.delete(id);
  }

  
  async clear() {
    await this.repoRole_Menus.deleteAll();
  }
}
