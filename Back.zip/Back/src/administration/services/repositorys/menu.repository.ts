import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Menu } from 'src/administration/entitys/menu.entity';
import { Repository, FindOptionsRelations } from 'typeorm';

@Injectable()
export class MenuRepository {
  constructor(
    @InjectRepository(Menu)
    private repo: Repository<Menu>,
  ) { }

  /**
   * Enregistrer une nouvelle transaction
   * @param data
   * @returns
   */
  async create(data: Partial<Menu>): Promise<Menu> {
    console.log('>>>>>>>>>>>>>>>>>>>>  create', data);
    return this.repo.save({ ...data });
  }

  async update(id: string, data: Partial<Menu>) {
    return this.repo.update({ id: id }, data);
  }

  async findAll(): Promise<Menu[]> {
    return this.repo.find();
  }

  async findOne(id: string): Promise<Menu | null> {
    return this.repo.findOne({ where: { id } });
  }
  async findOneByController(controller: string): Promise<Menu | null> {
    return this.repo.findOne({ where: { controller: controller } });
  }

  async findAllMenuPere(): Promise<Menu[] | null> {
    const menus = await this.repo.find({ where: { idPere: undefined } });
    return menus.length > 0 ? menus : null;
  }

  async findAllMenu(): Promise<Menu[]> {
    return await this.repo.find();
  }

  async clear(): Promise<void> {
    await this.repo.deleteAll();
  }
}
