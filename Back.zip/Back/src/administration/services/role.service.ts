import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RoleRepository } from './repositorys/role.repository';
import { CreateRoleDto } from '../definitions/dto/role/create-role.dto';
import { UpdateRoleDto } from '../definitions/dto/role/update-role.dto';
import { MenuRepository } from './repositorys/menu.repository';
import { Link_Role_Menu } from '../definitions/dto/role/link-role-menu.dto';
import { Role_MenuRepository } from './repositorys/role-menu.repository';
import { Role_Menu_Action } from '../definitions/dto/role/role-menu-action.dto';
import { Role_Menu_Action_Status } from '../definitions/enum/role-menu-action-status.enum';
import { ApiException } from 'src/common/definitions/class/api-exception';

@Injectable()
export class RoleService {
  constructor(
    private readonly roleRepository: RoleRepository,
    private readonly menuRepository: MenuRepository,
    private readonly roleMenuRepository: Role_MenuRepository,
  ) { }

  async create(input: CreateRoleDto) {
    try {
      let result = await this.roleRepository.findOneByLabel(input.label);
      //console.log('>>>>>>>>>>>>>>>>>>>>  createresult1',result)
      if (result != null) {
        throw new ApiException(
          'Echec de création, role existant',
          HttpStatus.BAD_REQUEST,
        );
      }
      //input.id = Utils.uuidv4();

      return await this.roleRepository.create(input);
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async update(input: UpdateRoleDto) {
    try {
      let result = await this.roleRepository.findOne(input.id);
      console.log('>>>>>>>>>>>>>>>>>>>>  update', result);
      console.log(input);
      if (result == null) {
        throw new ApiException(
          'Echec de la MAJ, role inexistant',
          HttpStatus.BAD_REQUEST,
        );
      }

      await this.roleRepository.update(input.id, { ...input });
      return await this.roleRepository.findOne(input.id);
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async get(id: string): Promise<any> {
    try {
      let result = await this.roleRepository.findOneWithMenu(id);
      if (result == null) {
        throw new ApiException('Aucun resultat', HttpStatus.BAD_REQUEST);
      }
      return result;
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async findOneWithMenu(id: string): Promise<any> {
    try {
      let result = await this.roleRepository.findOneWithMenu(id);
      if (result == null) {
        throw new ApiException('Aucun resultat', HttpStatus.BAD_REQUEST);
      }
      return result;
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async getAllMenuPere() {
    return await this.menuRepository.findAllMenuPere();
  }

  async getAllMenu() {
    return await this.menuRepository.findAllMenu();
  }

  async getAllRole(): Promise<any[] | null> {
    try {
      let result = await this.roleRepository.findAll();
      if (result == null) {
        return [];
      }
      return (
        result?.map((d) => ({
          id: d.id,
          label: d.label,
          status: d.status,
        })) || null
      );
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async linkRoleMenu(data: Link_Role_Menu) {
    try {
      const role = await this.roleRepository.findOne(data.idRole);
      const menu = await this.menuRepository.findOne(data.idMenu);
      //console.log('>>>>>>>>>>>>>>>>>>>>>>>  survey', survey);

      if (!role) {
        throw new ApiException('role not found');
      }

      if (!menu) {
        throw new ApiException('menu not found');
      }

      let existRelation = await this.roleMenuRepository.getRole_Menu(
        role,
        menu,
      );
      console.log('>>>>>>>>>>>>>>>>> newRelation 1', existRelation);

      console.log(
        '>>>>>>>>>>>>>>>>>>>>>>>  Survey_point_contact',
        existRelation,
      );
      if (existRelation == null) {
        const newRelation = this.roleMenuRepository.create(role, menu);

        await this.roleMenuRepository.save(newRelation);
        return { success: true };
      } else {
        throw new ApiException('Assignation impossible, lien existant');
      }
    } catch (error) {
      console.log('>>>>>>>>>>>>>>>>>>>>  ', error);
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error));
    }
  }

  async unlinkRoleMenu(data: Link_Role_Menu) {
    try {
      const role = await this.roleRepository.findOne(data.idRole);
      const menu = await this.menuRepository.findOne(data.idMenu);
      //console.log('>>>>>>>>>>>>>>>>>>>>>>>  survey', survey);

      if (!role) {
        throw new ApiException('role not found');
      }

      if (!menu) {
        throw new ApiException('menu not found');
      }

      let newRelation = await this.roleMenuRepository.getRole_Menu(role, menu);
      console.log('>>>>>>>>>>>>>>>>> newRelation 1', newRelation);

      if (newRelation == null) {
        throw new Error('survey or survey not found');
      }

      console.log('>>>>>>>>>>>>>>>>> newRelation', newRelation);
      await this.roleMenuRepository.delete(newRelation.id);
      return { success: true };
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async editRoleMenuAction(data: Role_Menu_Action) {
    try {
      const role = await this.roleRepository.findOne(data.idRole);
      const menu = await this.menuRepository.findOne(data.idMenu);
      //console.log('>>>>>>>>>>>>>>>>>>>>>>>  survey', survey);

      if (!role) {
        throw new ApiException('role not found');
      }

      if (!menu) {
        throw new ApiException('menu not found');
      }

      let existRelation = await this.roleMenuRepository.getRole_Menu(
        role,
        menu,
      );
      console.log('>>>>>>>>>>>>>>>>> newRelation 1', existRelation);

      if (existRelation != null) {
        switch (data.actionName) {
          case Role_Menu_Action_Status.CREATE:
            existRelation.create = data.status;
            break;
          case Role_Menu_Action_Status.READ:
            existRelation.read = data.status;
            break;
          case Role_Menu_Action_Status.UPDATE:
            existRelation.update = data.status;
            break;
          case Role_Menu_Action_Status.DELETE:
            existRelation.delete = data.status;
            break;
        }
        await this.roleMenuRepository.update(existRelation);
        return { success: true };
      } else {
        throw new ApiException('Assignation impossible, lien existant');
      }
    } catch (error) {
      console.log('>>>>>>>>>>>>>>>>>>>>  ', error);
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error));
    }
  }


}
