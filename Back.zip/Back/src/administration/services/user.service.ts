import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { UserRepository } from './repositorys/user.repository';
import { ApiException } from 'src/common/definitions/class/api-exception';
import { CreateUserDto } from '../definitions/dto/user/create-user.dto';
import { UpdateUserDto } from '../definitions/dto/user/update-user.dto';
import { RoleRepository } from './repositorys/role.repository';

@Injectable()
export class UserService {
  constructor(
    private readonly userRepository: UserRepository,
    private readonly roleRepository: RoleRepository,
  ) { }

  async create(input: CreateUserDto) {
    try {
      const existing = await this.userRepository.findOneByMatricule(input.login);
      if (existing != null) {
        throw new ApiException('Echec de création, utilisateur existant', HttpStatus.BAD_REQUEST);
      }

      let _role: import('../entitys/role.entity').Role | undefined = undefined;
      if (input.idRole) {
        const found = await this.roleRepository.findOne(input.idRole);
        if (found == null) {
          throw new ApiException('Echec de création, rôle inexistant', HttpStatus.BAD_REQUEST);
        }
        _role = found;
      }

      return await this.userRepository.create({ ...input, role: _role });
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async update(id: string, input: UpdateUserDto) {
    try {
      const result = await this.userRepository.findOne(id);
      if (result == null) {
        throw new ApiException('Echec de la MAJ, utilisateur inexistant', HttpStatus.BAD_REQUEST);
      }

      result.username    = input.username    ?? result.username;
      result.nom         = input.nom         ?? result.nom;
      result.prenoms     = input.prenoms     ?? result.prenoms;
      result.departement = input.departement ?? result.departement;
      result.telBur      = input.telBur      ?? result.telBur;
      result.service     = input.service     ?? result.service;
      result.direction   = input.direction   ?? result.direction;
      result.fonction    = input.fonction    ?? result.fonction;
      result.email       = input.email       ?? result.email;

      if (input.idRole) {
        const _role = await this.roleRepository.findOne(input.idRole);
        if (_role == null) {
          throw new ApiException('Echec de MAJ, rôle inexistant', HttpStatus.BAD_REQUEST);
        }
        result.role = _role;
      }

      await this.userRepository.update(result.id, { ...result });
      return await this.userRepository.findOne(result.id);
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async get(id: string): Promise<any> {
    try {
      const result = await this.userRepository.findOne(id);
      if (result == null) {
        throw new ApiException('Aucun résultat', HttpStatus.NOT_FOUND);
      }
      return result;
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  async getByLogin(login: string): Promise<any> {
    try {
      return await this.userRepository.findOneByMatricule(login) ?? null;
    } catch {
      return null;
    }
  }

  async getAllUser(): Promise<any[]> {
    try {
      const list = await this.userRepository.findAll();
      return (list ?? []).map((d) => ({
        id: d.id,
        login: d.login,
        nom: d.nom,
        prenoms: d.prenoms,
        email: d.email,
        telBur: d.telBur,
      }));
    } catch (error) {
      if (error instanceof HttpException) throw error;
      throw new ApiException(String(error), HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }
}
