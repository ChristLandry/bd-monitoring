import { Injectable } from "@nestjs/common";
import { MenuRepository } from "./repositorys/menu.repository";
import { Menu } from "../entitys/menu.entity";
import { createMenuDto, updateMenuDto } from "../definitions/dto/role/create-menu.dto";

@Injectable()
export class MenuService {
    constructor(
        private readonly menuRepository: MenuRepository,) { }

    async create(data: createMenuDto) {
        try {
            const existingMenu = await this.menuRepository.findOneByController(data.controller);
            console.log('>>>>>>>>>>>>>>>>>>>>  existingMenu', existingMenu);
            if (existingMenu == null) {
                return this.menuRepository.create(data);
            } else {
                throw new Error('Menu already exists');
            }
        } catch (error) {
            console.error('Error creating menu:', error);
        }
    }

    async update(id: string, data: updateMenuDto) {
        try {
            const existingMenu = await this.menuRepository.findOne(id);
            console.log('>>>>>>>>>>>>>>>>>>>>  existingMenu', existingMenu);
            if (!existingMenu) {
                return null;
            }
            let updatedMenu = Object.assign(existingMenu, data);

            const _updatedSetting = await this.menuRepository.update(
                id,
                updatedMenu,
            );
        } catch (error) {
            console.error('Error creating menu:', error);
        }
    }

}