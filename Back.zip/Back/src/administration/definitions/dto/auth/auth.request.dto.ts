import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString, IsStrongPassword } from 'class-validator';

export class AuthDto {
  @ApiProperty({})
  @IsNotEmpty()
  @IsString()
  login: string;

  @ApiProperty({})
  @IsNotEmpty()
  password: string;
}
