import { IsString, IsEmail, IsObject } from 'class-validator';

export class UserResponseDto {
  login: string;

  username: string;

  nom: string;

  prenoms: string;

  departement: string;

  situationGeo: string;

  email: string;

  fonction: string;

  telBur: string;

  id: string;

  service: string;

  direction: string;

  codeExploitant: string;
}

