import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsString } from "class-validator";

export class UpdateRoleDto {
  id:string
  
  @ApiProperty({})
  @IsNotEmpty()
  @IsString()
   label: string;

  @ApiProperty({})
  status: boolean;
}