import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsUUID } from 'class-validator';

export class Link_Role_Menu {
  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  @IsUUID()
  idRole: string;

  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  @IsUUID()
  idMenu: string;
}
