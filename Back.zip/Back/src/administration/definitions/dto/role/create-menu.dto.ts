import { ApiProperty } from "@nestjs/swagger";
import { IsNotEmpty, IsOptional, IsString } from "class-validator";

export class createMenuDto {
    @ApiProperty({})
    @IsString()
    @IsOptional()
    idPere?: string;

    @ApiProperty({})
    @IsNotEmpty()
    @IsString()
    title: string;

    @ApiProperty({})
    @IsNotEmpty()
    @IsString()
    controller: string;

    @ApiProperty({})
    @IsNotEmpty()
    @IsString()
    icon: string;
}

export class updateMenuDto {
    @ApiProperty({})
    @IsString()
    @IsOptional()
    idPere?: string;

    @ApiProperty({})
    @IsOptional()
    @IsString()
    title?: string;

    @ApiProperty({})
    @IsOptional()
    @IsString()
    controller?: string;

    @ApiProperty({})
    @IsOptional()
    @IsString()
    icon?: string;
}