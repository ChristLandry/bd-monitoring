import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsUUID, IsEnum, isEnum, IS_ENUM, IsBoolean } from 'class-validator';
import { Role_Menu_Action_Status } from '../../enum/role-menu-action-status.enum';

export class Role_Menu_Action {
  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  @IsUUID()
  idRole: string;

  @ApiProperty({})
  @IsString()
  @IsNotEmpty()
  @IsUUID()
  idMenu: string;

  @ApiProperty({})
  @IsNotEmpty()
  actionName: Role_Menu_Action_Status;

  @ApiProperty({})
  @IsBoolean()
  status: boolean;
}
