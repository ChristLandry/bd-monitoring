import { ApiProperty } from '@nestjs/swagger';
import {
  IsString,
  IsEmail,
  IsNotEmpty,
  IsEmpty,
  IsOptional,
} from 'class-validator';

export class UpdateUserDto {
  //id?: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  username: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  nom: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  prenoms: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  departement: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  situationGeo: string;

  @ApiProperty({})
  @IsNotEmpty()
  @IsString()
  @IsEmail()
  email: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  fonction: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  telBur: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  service: string;

  @ApiProperty({})
  @IsOptional()
  @IsString()
  direction: string;


  @ApiProperty({})
  @IsOptional()
  @IsString()
  idRole: string;
}
