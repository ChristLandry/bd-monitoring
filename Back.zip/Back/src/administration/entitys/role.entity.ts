
import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Role_Menus } from './role-menus.entity';
import { Users } from './user.entity';
import { Utils } from 'src/common/utils/utils';

@Entity('roles')
export class Role {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id: string = Utils.uuidv4();

  @Column({ nullable: false, unique: true })
  label: string;

  @Column({ nullable: false })
  status: boolean;

  @OneToMany((type) => Users, (user) => user.role)
  users: Users[];

  @OneToMany(() => Role_Menus, (role_Menus) => role_Menus.role)
  role_Menus: Role_Menus[];
}
