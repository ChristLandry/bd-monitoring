import { Column, Entity, ManyToOne, PrimaryGeneratedColumn } from 'typeorm';
import { Role } from './role.entity';

@Entity('users')
export class Users {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id: string;

  @Column({ nullable: false, unique: true })
  login: string;

  @Column({ nullable: true })
  username: string;

  @Column({ nullable: true })
  nom: string;

  @Column({ nullable: true })
  prenoms: string;

  @Column({ nullable: true })
  departement: string;

  @Column({ nullable: true })
  situationGeo: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  fonction: string;

  @Column({ nullable: true })
  telBur: string;

  @Column({ nullable: true })
  service: string;

  @Column({ nullable: true })
  direction: string;

  @Column({ nullable: true })
  codeExploitant: string;

  @ManyToOne((type) => Role, (role) => role.users)
  role: Role;
}
