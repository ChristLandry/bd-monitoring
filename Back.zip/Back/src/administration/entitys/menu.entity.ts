
import {
  Column,
  Entity,
  ManyToOne,
  OneToMany,
  PrimaryColumn,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Role_Menus } from './role-menus.entity';
import { Utils } from 'src/common/utils/utils';
@Entity('menus')
export class Menu {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id: string = Utils.uuidv4();

  @Column({ nullable: true })
  idPere: string;

  @Column({ nullable: false })
  title: string;

  @Column({ nullable: false, unique: true })
  controller: string;

  @Column({ nullable: false })
  icon: string;

  @OneToMany(() => Role_Menus, (role_Menus) => role_Menus.menu)
  role_Menus: Role_Menus[];
}
