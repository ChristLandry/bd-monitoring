import {
  Column,
  Entity,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Menu } from './menu.entity';
import { Role } from './role.entity';

@Entity('role_menus')
export class Role_Menus {
  @PrimaryGeneratedColumn('uuid', { name: 'id' })
  id: string;

  @Column({ nullable: true,default:false })
  create: boolean;

  @Column({ nullable: true,default:false })
  read: boolean;

  @Column({ nullable: true,default:false })
  update: boolean;

  @Column({ nullable: true,default:false })
  delete: boolean;

  @ManyToOne(() => Role, (role) => role.role_Menus)
  // @JoinColumn({ name: 'point_contact_id' })
  role: Role;

  @ManyToOne(() => Menu, (menu) => menu.role_Menus)
  //@JoinColumn({ name: 'survey_id' })
  menu: Menu;
}
