import { Post, Body, Put, Param, Get, Controller } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { RoleService } from '../services/role.service';
import { CreateRoleDto } from '../definitions/dto/role/create-role.dto';
import { UpdateRoleDto } from '../definitions/dto/role/update-role.dto';
import { Link_Role_Menu } from '../definitions/dto/role/link-role-menu.dto';
import { Role_Menu_Action } from '../definitions/dto/role/role-menu-action.dto';
import { MenuService } from '../services/menu.service';
import { createMenuDto, updateMenuDto } from '../definitions/dto/role/create-menu.dto';

@ApiTags('Administration – Rôles & Menus')
@Controller('role')
export class RoleController {
  constructor(
    private readonly roleService: RoleService,
    private readonly menuService: MenuService,
  ) {}

  // ─── Menus ─────────────────────────────────────────────────────────────────

  @Post('menu')
  @ApiOperation({ summary: 'Créer un menu de navigation' })
  @ApiResponse({ status: 201, description: 'Menu créé' })
  async createMenu(@Body() input: createMenuDto) {
    return this.menuService.create(input);
  }

  @Put('menu/:id')
  @ApiOperation({ summary: 'Mettre à jour un menu' })
  @ApiParam({ name: 'id', description: 'UUID du menu' })
  async updateMenu(@Param('id') id: string, @Body() input: updateMenuDto) {
    return this.menuService.update(id, input);
  }

  @Get('list/menu')
  @ApiOperation({ summary: 'Lister tous les menus' })
  async getAllMenu() {
    return this.roleService.getAllMenu();
  }

  // ─── Rôles ─────────────────────────────────────────────────────────────────

  @Post()
  @ApiOperation({ summary: 'Créer un rôle' })
  @ApiResponse({ status: 201, description: 'Rôle créé' })
  async create(@Body() input: CreateRoleDto) {
    return this.roleService.create(input);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Mettre à jour un rôle' })
  @ApiParam({ name: 'id', description: 'UUID du rôle' })
  async update(@Param('id') id: string, @Body() input: UpdateRoleDto) {
    input.id = id;
    return this.roleService.update(input);
  }

  @Get(':id/detail')
  @ApiOperation({ summary: 'Obtenir les détails d\'un rôle avec ses menus' })
  @ApiParam({ name: 'id', description: 'UUID du rôle' })
  async get(@Param('id') id: string) {
    return this.roleService.get(id);
  }

  @Get('list')
  @ApiOperation({ summary: 'Lister tous les rôles' })
  async getAll() {
    return this.roleService.getAllRole();
  }

  // ─── Liaison Rôle ↔ Menu ──────────────────────────────────────────────────

  @Post('link-role-menu')
  @ApiOperation({ summary: 'Associer un menu à un rôle' })
  async linkRoleMenu(@Body() input: Link_Role_Menu) {
    return this.roleService.linkRoleMenu(input);
  }

  @Post('unlink-role-menu')
  @ApiOperation({ summary: 'Dissocier un menu d\'un rôle' })
  async unlinkRoleMenu(@Body() input: Link_Role_Menu) {
    return this.roleService.unlinkRoleMenu(input);
  }

  @Post('edit-menu-action')
  @ApiOperation({ summary: 'Modifier les permissions CRUD d\'un rôle sur un menu' })
  async editRoleMenuAction(@Body() input: Role_Menu_Action) {
    return this.roleService.editRoleMenuAction(input);
  }
}
