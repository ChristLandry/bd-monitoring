import { Body, Controller, Get, Param, Post, Put } from '@nestjs/common';
import { ApiOperation, ApiParam, ApiResponse, ApiTags } from '@nestjs/swagger';
import { AuthDto } from '../definitions/dto/auth/auth.request.dto';
import { AuthService } from '../services/auth.service';
import { UserService } from '../services/user.service';
import { CreateUserDto } from '../definitions/dto/user/create-user.dto';
import { UpdateUserDto } from '../definitions/dto/user/update-user.dto';

@ApiTags('Administration – Utilisateurs')
@Controller('user')
export class UserController {
  constructor(
    private readonly authService: AuthService,
    private readonly userService: UserService,
  ) {}

  // ─── Authentification ─────────────────────────────────────────────────────

  @Post('auth')
  @ApiOperation({ summary: 'Authentification (LDAP BNI ou Super_Admin)' })
  @ApiResponse({
    status: 200,
    description: 'Résultat de l\'authentification',
    schema: {
      example: {
        success: true,
        user: {
          id: 'uuid',
          login: 'jdupont',
          nom: 'Dupont',
          prenoms: 'Jean',
          email: 'jdupont@bni.ci',
          role: { id: 'uuid', label: 'Admin', status: true },
        },
      },
    },
  })
  async auth(@Body() input: AuthDto) {
    return this.authService.auth(input);
  }

  @Get(':login/ldap/infos')
  @ApiOperation({ summary: 'Récupérer les informations LDAP d\'un utilisateur' })
  @ApiParam({ name: 'login', example: 'jdupont' })
  async getUserLdap(@Param('login') login: string) {
    return this.authService.getUserLdap(login);
  }

  // ─── CRUD Utilisateur ──────────────────────────────────────────────────────

  @Post()
  @ApiOperation({ summary: 'Créer un utilisateur' })
  @ApiResponse({ status: 201, description: 'Utilisateur créé' })
  async create(@Body() input: CreateUserDto) {
    return this.userService.create(input);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Mettre à jour un utilisateur' })
  @ApiParam({ name: 'id', description: 'UUID de l\'utilisateur' })
  async update(@Param('id') id: string, @Body() input: UpdateUserDto) {
    return this.userService.update(id, input);
  }

  @Get(':id/detail')
  @ApiOperation({ summary: 'Obtenir les détails d\'un utilisateur' })
  @ApiParam({ name: 'id', description: 'UUID de l\'utilisateur' })
  async get(@Param('id') id: string) {
    return this.userService.get(id);
  }

  @Get('list')
  @ApiOperation({ summary: 'Lister tous les utilisateurs' })
  async getAll() {
    return this.userService.getAllUser();
  }
}
