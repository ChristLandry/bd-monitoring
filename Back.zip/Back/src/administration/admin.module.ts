import { TypeOrmModule } from "@nestjs/typeorm";
import { Module } from "@nestjs/common";
import { UserController } from "./controllers/user.controller";
import { AuthService } from "./services/auth.service";
import { Menu } from "./entitys/menu.entity";
import { Role_Menus } from "./entitys/role-menus.entity";
import { Role } from "./entitys/role.entity";
import { Users } from "./entitys/user.entity";
import { RoleRepository } from "./services/repositorys/role.repository";
import { UserRepository } from "./services/repositorys/user.repository";
import { RoleService } from "./services/role.service";
import { UserService } from "./services/user.service";
import { MenuRepository } from "./services/repositorys/menu.repository";
import { Role_MenuRepository } from "./services/repositorys/role-menu.repository";
import { MenuService } from "./services/menu.service";
import { RoleController } from "./controllers/role.controller";

@Module({
    imports: [
        TypeOrmModule.forFeature([Role,Users,Role_Menus,Menu])
    ],
    providers: [
      MenuRepository,Role_MenuRepository, UserRepository,RoleRepository,UserService,RoleService, AuthService,MenuService
    ],
    exports: [
      Role_MenuRepository,MenuRepository,MenuService
    ],
    controllers: [
      UserController,RoleController
    ]
})
export class AdminModule {}