export default class ClientOptions {
  username?: string;
  password?: string;
  clientId?: string;
  clientSecret?: string;
  baseUrl?: string;
  authUrl?: string;
  validateSSL?: boolean;
  productPath?: string;
  requester?: string;
}
