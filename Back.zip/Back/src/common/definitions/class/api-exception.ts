import { HttpException } from "@nestjs/common";

export class ApiException extends HttpException{
    code: string|number|undefined
    timestamp: number;

    constructor(message: string | Record<string, any>, code?: string|number, status: number = 500, ){
        const tsp = Date.now()
        super({
            statusCode: code || 500,
            message: message,
            timestamp: tsp
        }, status)
        this.code = code 
        this.timestamp = tsp   
    }
}