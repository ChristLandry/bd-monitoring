import { AuthentificationResponse } from './authentification-response';
import { ApiClient } from './api-client';
import ClientOptions from './client-options';
const qs = require('qs');

export class GenericAPIClient extends ApiClient {
  protected accessToken: string = '';

  constructor(opts?: ClientOptions) {
    super(opts);
    // Reconfigure l'instance axios avec SSL désactivé (certificats internes BNI)
    this.configureAxiosInstance(opts);
  }

  async authenticate(
    clientId?: string,
    clientSecret?: string,
    url: string = 'apim/oauth2/token',
  ): Promise<AuthentificationResponse> {
    const id = clientId || this.options?.clientId || this.options?.username || '';
    const secret = clientSecret || this.options?.clientSecret || this.options?.password || '';

    const authUrl = this.options?.authUrl || '';

    // Si authUrl est une URL absolue (http/https), l'utiliser directement sans ajouter url
    // Sinon, concaténer authUrl + url (authUrl = base URL uniquement)
    const fullUrl = authUrl.startsWith('http')
      ? authUrl                       // authUrl contient déjà le chemin complet
      : authUrl
        ? `${authUrl}/${url}`         // authUrl = base, on ajoute le chemin
        : url;                        // pas d'authUrl, on utilise url tel quel

    const response = await this.axiosInstance.request<AuthentificationResponse>({
      method: 'POST',
      url: fullUrl,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${Buffer.from(`${id}:${secret}`).toString('base64')}`,
      },
      data: qs.stringify({
        grant_type: 'client_credentials',
      }),
    });

    this.accessToken = response.data?.access_token || '';
    return response.data;
  }

  protected override async getDefaultHeaders(): Promise<Record<string, string>> {
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.accessToken}`,
    };
  }
}
