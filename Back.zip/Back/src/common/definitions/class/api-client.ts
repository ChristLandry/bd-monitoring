import axios, { AxiosInstance } from 'axios';
import * as https from 'https';
import { AuthentificationResponse } from './authentification-response';
import ClientOptions from './client-options';

export { ClientOptions };

export class ApiClient {
  protected axiosInstance: AxiosInstance;
  protected options: ClientOptions;

  constructor(opts?: ClientOptions) {
    this.options = opts || {};
    this.axiosInstance = axios.create({
      baseURL: opts?.baseUrl,
      httpsAgent: new https.Agent({ rejectUnauthorized: opts?.validateSSL !== false ? true : false }),
    });
  }

  protected configureAxiosInstance(opts?: ClientOptions): void {
    this.axiosInstance = axios.create({
      baseURL: opts?.baseUrl || this.options?.baseUrl,
      httpsAgent: new https.Agent({ rejectUnauthorized: false }),
    });
  }

  protected async getDefaultHeaders(): Promise<Record<string, string>> {
    return {
      'Content-Type': 'application/json',
    };
  }
}
