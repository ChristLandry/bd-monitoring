import { Injectable } from '@nestjs/common';
import moment from 'moment';

@Injectable()
export class DateManagerFormatService {
  /**
   * Formate une date dans le format attendu par l'API CORE.
   * @param date La date à formater
   * @param format Le format de sortie (par défaut 'DD-MM-YYYY')
   */
  getDateCoreFormat(date?: Date | string, format: string = 'DD-MM-YYYY'): string {
    if (!date) {
      return moment().format(format);
    }
    return moment(date).format(format);
  }

  /**
   * Parse une chaîne de date retournée par l'API CORE.
   * @param dateString La chaîne à parser
   */
  parseDate(dateString?: string): Date | null {
    if (!dateString) return null;
    const parsed = moment(dateString, ['DD-MM-YYYY', 'YYYY-MM-DD', 'DD/MM/YYYY', moment.ISO_8601], true);
    return parsed.isValid() ? parsed.toDate() : null;
  }
}
