var fs = require('fs');
var crypto = require('crypto');
import { Request } from 'express';
import { hash, compare } from 'bcryptjs';
import { v4 as uuidv4, validate as isValidUUID } from 'uuid';
import { decode as jwtDecode, JwtPayload } from 'jsonwebtoken';
import moment from 'moment';
import { DiscoveryService, ModuleRef } from '@nestjs/core';
import { InjectionToken } from '@nestjs/common';

export function extendArrayMetadata<T extends Array<unknown>>(
  key: string,
  metadata: T,
  target: Function,
) {
  const previousValue = Reflect.getMetadata(key, target) || [];
  const value = [...previousValue, ...metadata];
  Reflect.defineMetadata(key, value, target);
}

export class Utils {
  private static vector: string = '0123456789abcdef';

  // ======================
  // Manipulation des dates
  // ======================
  static getCurrentTime() {
    return Math.floor(new Date().getTime() / 1000);
  }

  static addToCurrentTime(
    amount?: moment.DurationInputArg1,
    unit: moment.DurationInputArg2 = 's',
  ): Date {
    return moment().add(amount, unit).toDate();
  }

  static toDate(dateString: string, formatString: string): Date {
    const momentObj = moment(dateString, formatString);
    const dateObject = momentObj.toDate();
    //console.log("dateObject", dateObject)
    return dateObject;
  }

  static addToDate(
    date: Date,
    amount?: moment.DurationInputArg1,
    unit: moment.DurationInputArg2 = 's',
  ): Date {
    return moment(date).add(amount, unit).toDate();
  }

  static addSecondToCurrentTime(seconds: number): Date {
    return Utils.addToCurrentTime(seconds, 's');
  }

  static momentDisplay(
    date?: string | Date,
    asDuration: boolean = false,
    format?: string,
    locale: string = 'fr',
  ) {
    if (date == null || date == undefined) date = new Date();

    moment.locale(locale);

    //if (!format || typeof format !== "string") format = "Do MMMM YYYY, hh:mm:ss"

    let parsedDate = moment(date);
    let formatedDate = moment(date).format(format);

    if (asDuration === true) {
      let duration = moment().diff(parsedDate);
      const formatedDuration = moment.duration(duration, 'ms').humanize(true);
      return formatedDuration;
    }

    return formatedDate;
  }

  static startOfCurrentWeek(): Date {
    const startOfWeek = new Date();
    startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay()); // Lundi de cette semaine
    startOfWeek.setHours(0, 0, 0, 0);
    return startOfWeek;
  }

  static convertDateToMysqlDate(date: Date) {
    // Formatage au format MySQL (YYYY-MM-DD)
    return date?.toISOString().slice(0, 19).replace('T', ' ');
  }

  static endOfCurrentWeek() {
    const endOfWeek = new Date();
    endOfWeek.setDate(endOfWeek.getDate() + (6 - endOfWeek.getDay())); // Dimanche de cette
    return endOfWeek;
  }

  static startOfLastWeek(): Date {
    const startOfLastWeek = new Date();
    startOfLastWeek.setDate(
      startOfLastWeek.getDate() - startOfLastWeek.getDay() - 7,
    ); // Lundi de la semaine précédente
    startOfLastWeek.setHours(0, 0, 0, 0);
    return startOfLastWeek;
  }

  static endOfLastWeek(): Date {
    const endOfLastWeek = new Date();
    endOfLastWeek.setDate(endOfLastWeek.getDate() - endOfLastWeek.getDay() - 1); // Dimanche de la semaine précédente
    endOfLastWeek.setHours(23, 59, 59, 999);
    return endOfLastWeek;
  }

  static startOfCurrentMonth(): Date {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1; // Mois en cours (0-11)
    return new Date(currentYear, currentMonth - 1, 1); // Mois est 0-indexé
  }

  static endOfCurrentMonth(): Date {
    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + 1; // Mois en cours (0-11)
    return new Date(currentYear, currentMonth, 0); // 0 renvoie le dernier jour du mois précédent
  }

  static startOfCurrentYear(): Date {
    const currentYear = new Date().getFullYear();
    // Date de début : premier jour de l'année en cours
    return new Date(currentYear, 0, 1); // Janvier est le mois 0
  }

  static endOfCurrentYear(): Date {
    const currentYear = new Date().getFullYear();
    // Date de fin : dernier jour de l'année en cours
    return new Date(currentYear + 1, 0, 0); // 0 renvoie le dernier jour du mois précédent (décembre)
  }

  static startOfCurrentDay() {
    const today = new Date();
    // Date de début : début de la journée en cours
    return new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
      0,
      0,
      0,
    );
  }

  static endOfCurrentDay() {
    const today = new Date();
    // Date de fin : fin de la journée en cours
    return new Date(
      today.getFullYear(),
      today.getMonth(),
      today.getDate(),
      23,
      59,
      59,
    );
  }

  /**
   *
   * @param data
   * @param algorithm
   * @param encoding
   * @returns
   */
  private static computeChecksum(
    data,
    encoding: 'hex' | 'utf8',
    algorithm: string = 'md5',
  ): string {
    var checksum = '';
    if (data != null) {
      checksum = crypto
        .createHash(algorithm || 'md5')
        .update(data, 'utf8')
        .digest(encoding || 'hex');
    }
    return checksum;
  }

  /**
   *
   * @param file
   * @param algorithm
   * @param encoding
   * @returns
   */
  public static generateChecksumAsync(
    file: string,
    encoding: 'hex' | 'utf8',
    algorithm: string = 'md5',
  ): Promise<string> {
    return new Promise((resolve, reject) => {
      fs.readFile(file, function (err, data: string) {
        if (err) return reject(err);
        var checksum = Utils.computeChecksum(data, encoding, algorithm);
        //console.log(checksum);
        resolve(checksum);
      });
    });
  }

  /**
   *
   * @param file
   * @param algorithm
   * @param encoding
   * @returns
   */
  public static generateChecksum(
    file: string,
    algorithm: string = 'md5',
    encoding: 'hex' | 'utf8',
  ) {
    try {
      const data = fs.readFileSync(file);
      var checksum = Utils.computeChecksum(data, encoding, algorithm);
      //console.log(checksum);
      return checksum;
    } catch (error) {
      return null;
    }
  }

  public static getMetatdata(
    metadataKey: any,
    target: any,
    propertyKey: string,
  ) {
    return Reflect.getMetadata(metadataKey, target, propertyKey);
  }

  public static genNumericOnly(length: number = 16): string {
    return this.genId(length, '0123456789');
  }

  public static genStringOnly(length: number = 16): string {
    return this.genId(
      length,
      'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz',
    );
  }

  public static genId(
    length: number = 16,
    chars: string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',
  ): string {
    return [...Array(length)].reduce(
      (a) => a + chars[~~(Math.random() * chars.length)],
      '',
    );
  }

  public static assign(target: { [key: string]: any }, ...sources: object[]) {
    sources.forEach((source) => {
      return Object.keys(source).forEach((key) => {
        target[key] = source[key as keyof Object];
      });
    });
    return target;
  }

  /**
   * Get Multiple Random Elements from an Array in JavaScript
   * @param arr Array for get random elements from
   * @param num Number of elements to randomly return
   * @returns
   */
  public static getMultipleRandom<T>(arr: Array<T>, num?: number): Array<T> {
    if (!num) num = arr?.length;
    const shuffled = [...arr].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, num);
  }

  public static isEmptyString(value?: string): boolean {
    if (value) (value += '').trim();
    return value === '' || value == null || value == undefined;
  }

  public static jwtDecode(
    signedJwtAccessToken: string,
  ): null | JwtPayload | string {
    try {
      return jwtDecode(signedJwtAccessToken);
    } catch (error) {
      return null;
    }
  }

  static extractTokenFromHeader(request: Request): string | undefined {
    const [type, token] = request.headers.authorization?.split(' ') ?? [];
    return type === 'Bearer' ? token : undefined;
  }

  public static generateNumberRangeArray(
    length: number,
  ): IterableIterator<number> {
    return Array(length).keys();
  }

  public static uuidv4() {
    return uuidv4();
  }

  public static generateClientId(): string {
    return Utils.uuidv4().replace(/-/g, '');
  }

  public static generateClientSecret(): string {
    return (Utils.uuidv4() + Utils.uuidv4()).replace(/-/g, '');
  }

  public static async hashCompare(
    attempt: string,
    hashValue: string,
  ): Promise<boolean> {
    if (!hashValue) return false;
    return await compare(attempt, hashValue);
  }

  public static async hash(valueToHash: string): Promise<string | null> {
    if (!valueToHash) return null;
    return await hash(valueToHash, 10);
  }

  static getMonthName(
    monthNumber: number,
    format:
      | 'numeric'
      | '2-digit'
      | 'long'
      | 'short'
      | 'narrow'
      | undefined = 'long',
    locale: string = 'fr-FR',
  ) {
    const date = new Date();
    date.setMonth(monthNumber - 1);

    let result = date.toLocaleString(locale, {
      month: format,
    });

    return result;
  }

  static getCurrentMonthNumber() {
    return new Date().getMonth() + 1;
  }

  static GFG_Fun(n: string): number {
    let result = n.indexOf('.') >= 0 ? (n + '').split('.')[1] : n;
    return Number(result);
  }

  static encrypt(
    text: string,
    secret: string,
    vector: string = Utils.vector,
    algorithm = 'aes-256-cbc',
  ) {
    try {
      const key = crypto.scryptSync(secret, 'salt', 32); // Générer une clé à partir du secret
      const iv = Buffer.from(vector);
      const cipher = crypto.createCipheriv(algorithm, key, iv);
      let encrypted = cipher.update(text, 'utf8', 'hex');
      encrypted += cipher.final('hex');
      return encrypted; // Retourner seulement les données chiffrées
    } catch (error) {
      console.error(error);
      return '';
    }
  }

  static decrypt(
    encryptedText: string,
    secret: string,
    vector: string = Utils.vector,
    algorithm = 'aes-256-cbc',
  ) {
    try {
      const key = crypto.scryptSync(secret, 'salt', 32);
      const iv = Buffer.from(vector);
      const decipher = crypto.createDecipheriv(algorithm, key, iv); // Utiliser l'IV fixe
      let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
      decrypted += decipher.final('utf8');
      return decrypted;
    } catch (error) {
      console.error(error);
      return null;
    }
  }

  static getRandomInt(max: number) {
    return Math.floor(Math.random() * max);
  }

  /**
   * Mettre l'appelant en pause pendant x milli secondes.
   * @param seconds
   * @returns
   */
  static pauseForSeconds(duration: number) {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve('resolved');
      }, duration);
    });
  }

  static getRandomItem<T>(list: T[]): T | undefined {
    const random = Math.floor(Math.random() * list?.length);
    return random < list?.length ? list[random] : undefined;
  }

  static isValidEnumValue<T>(value: any, enumType: any): value is T {
    return Object.values(enumType).includes(value as T);
  }

  static isInEnum<T>(enumType: any, ...values: T[]) {
    if (Array.isArray(values)) {
      let isIn: boolean = true;
      values.forEach((value) => {
        isIn = isIn && (Object.values(enumType) as T[]).includes(value);
      });
      return isIn;
    } else {
      return (Object.values(enumType) as T[]).includes(values);
    }
  }

  static isValidUUID(value: string) {
    return isValidUUID(value);
  }

  static extractMustachePlaceholders(templateString): {
    placeholders: string[];
    properties: string[];
  } {
    const regex = /{{\s*([a-zA-Z0-9_]+)\s*}}/g;
    let match: RegExpExecArray | null;
    let placeholders: string[] = [];
    let properties: string[] = [];
    while ((match = regex.exec(templateString)) !== null) {
      placeholders.push(match[0]);
      properties.push(match[1]);
    }
    return {
      placeholders: placeholders,
      properties: properties,
    };
  }

  static randomStringFromRegExp(regExp: string) {
    const RandExp = require('randexp');
    // Example 2: Generate a random string matching a more complex pattern
    const complexPattern = new RandExp(regExp);
    const randomString2 = complexPattern.gen();
    return randomString2;
  }

  static isEmail(email: string) {
    if (Utils.isEmptyString(email)) return false;
    var emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (email !== '' && email.match(emailFormat)) {
      return true;
    }
    return false;
  }

  /**
   * Hides the middle of a string with a specified character (e.g., ellipsis).
   * @param {string} fullText The original string.
   * @param {number} startChars The number of characters to show at the start.
   * @param {number} endChars The number of characters to show at the end.
   * @param {string} [placeholder='...'] The string to use for the hidden middle.
   * @returns {string} The formatted string.
   */
  static hideMiddleText(
    fullText: string,
    startChars: number,
    endChars: number,
    placeholder: string = '...',
  ) {
    if (fullText.length <= startChars + endChars + placeholder.length) {
      // Return original text if it's short enough not to need hiding
      return fullText;
    }

    const start = fullText.slice(0, startChars);
    const end = fullText.slice(-endChars);

    return start + placeholder + end;
  }

  static sumField(array: any[], fieldName: string) {
    const totalSum = array.reduce((accumulator, currentValue) => {
      // Add the current object's field value to the accumulator
      return accumulator + currentValue[fieldName];
    }, 0); // The '0' is the initial value of the accumulator
    return totalSum;
  }

  static getPreviousMonthDateRange() {
    // Start date of the previous month
    const startDate = moment().subtract(1, 'months').startOf('month');

    // End date of the previous month
    const endDate = moment().subtract(1, 'months').endOf('month');

    return {
      startDate: startDate.toDate(),
      endDate: endDate.toDate(),
    };
  }

  static dateFormat(date?: Date, format: string = 'YYYY-MM-DD') {
    return moment(date || undefined).format(format);
  }

  static getPreviousMonthDateRangeAsString(format: string = 'YYYY-MM-DD') {
    // Start date of the previous month
    const startDate = moment().subtract(1, 'months').startOf('month');

    // End date of the previous month
    const endDate = moment().subtract(1, 'months').endOf('month');

    // Optional: Format the dates as strings (e.g., 'YYYY-MM-DD')
    const startDateFormatted = startDate.format(format);
    const endDateFormatted = endDate.format(format);

    return {
      startDate: startDateFormatted,
      endDate: endDateFormatted,
    };
  }

  static getPreviousMonthDateRangej() {
    const today = new Date();

    // To get the first day of the previous month:
    // Create a new date with the current year, the previous month index (getMonth() - 1),
    // and the day set to 1. JavaScript Date objects automatically handle month/year rollovers.
    const startOfPreviousMonth = new Date(
      today.getFullYear(),
      today.getMonth() - 1,
      1,
    );

    // To get the last day of the previous month:
    // Create a new date with the current year, the current month index (getMonth()),
    // and the day set to 0. Setting the day to 0 automatically results
    // in the last day of the *previous* month.
    const endOfPreviousMonth = new Date(
      today.getFullYear(),
      today.getMonth(),
      0,
    );

    return {
      start: startOfPreviousMonth,
      end: endOfPreviousMonth,
    };
  }

  /**
   * Gets an array of objects for the last n months, formatted in a specific locale.
   * @param {number} n The number of months to retrieve (e.g., 3 for last 3 months).
   * @param {string} localeCode The locale code (e.g., 'en', 'fr', 'es').
   * @returns {Array<object>} An array of month objects with name and start/end dates.
   */
  static getLastNMonths(
    n: number,
    localeCode: string,
    dateFormat: string = 'YYYY-MM-DD',
    monthFormat: string = 'MMMM',
  ) {
    return Utils.getLastNUnitOfTime(
      n,
      'months',
      localeCode,
      dateFormat,
      monthFormat,
    );
  }

  /**
   * Gets an array of objects for the last n unit, formatted in a specific locale.
   * @param {number} n The number of unit to retrieve (e.g., 3 for last 3 months).
   * @param {string} localeCode The locale code (e.g., 'en', 'fr', 'es').
   * @returns {Array<object>} An array of month objects with name and start/end dates.
   */
  static getLastNUnitOfTime(
    n: number,
    unit: moment.unitOfTime.DurationConstructor,
    localeCode: string,
    dateFormat: string = 'YYYY-MM-DD',
    unitFormat?: string,
  ) {
    // Set the global locale for Moment.js
    moment.locale(localeCode);

    const results: any[] = [];
    // Start with the current moment to ensure all operations are relative to "now"
    let currentMoment = moment();

    for (let i = 0; i < n; i++) {
      // Clone the moment object to avoid mutating the original in the loop
      const start = currentMoment.clone().subtract(i, unit).startOf(unit);
      const end = currentMoment.clone().subtract(i, unit).endOf(unit);

      results.push({
        name: start.format(unitFormat), // Unit name in the specified language
        startDate: start.format(dateFormat), // Start date
        endDate: end.format(dateFormat), // End date
      });
    }

    // Reverse the array to have the most recent month last (chronological order)
    return results.reverse();
  }

  static getProvider(
    token: InjectionToken,
    discoveryService: DiscoveryService,
    moduleRef: ModuleRef,
  ) {
    let result: any;
    const providers = discoveryService.getProviders();
    providers.forEach((provider) => {
      try {
        if (provider.token == token) {
          result = moduleRef.get(token, { strict: false });
        }
      } catch (error) {}
    });
    return result;
  }

  /*
    static findOne<T>(array: T[], predicate: (value: T, index: number, obj: T[]) => unknown, thisArg?: any) : T | undefined{
        let result = array.find(predicate)
        let res: T = result
    }
    */

  // Duration | number | string | FromTo | DurationInputObject | null | undefined
}
